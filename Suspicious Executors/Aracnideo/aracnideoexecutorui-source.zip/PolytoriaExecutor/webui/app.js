const SCRIPTLYTORIA_BASE = "https://mshashiyynxlkkvfabym.supabase.co/functions/v1";

const $ = (id) => document.getElementById(id);

const state = {
  searchLoaded: false,
  searchResults: [],
  theme: "green",
  vpnEnabled: false,
  vpnBusy: false,
};

let editor = null;

function hasHost() {
  return !!(window.chrome && window.chrome.webview);
}

function uuid() {
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}

const pending = new Map();

function send(type, payload = {}, timeoutMs = 8000) {
  if (!hasHost()) return Promise.reject(new Error("no_host"));
  const id = uuid();
  const msg = { id, type, payload };
  window.chrome.webview.postMessage(msg);
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject, ts: Date.now() });
    setTimeout(() => {
      const p = pending.get(id);
      if (!p) return;
      pending.delete(id);
      reject(new Error("timeout"));
    }, timeoutMs);
  });
}

function toast(title, body) {
  const t = $("toast");
  $("toastTitle").textContent = title || "";
  $("toastBody").textContent = body || "";
  t.hidden = false;
  t.style.opacity = "1";
  clearTimeout(toast._t);
  toast._t = setTimeout(() => {
    t.style.opacity = "0";
    setTimeout(() => (t.hidden = true), 220);
  }, 2200);
}

function themes() {
  return [
    { id: "blue", label: "Blue", rgb: [70, 140, 255] },
    { id: "green", label: "Green", rgb: [182, 255, 26] },
    { id: "red", label: "Red", rgb: [255, 77, 77] },
    { id: "orange", label: "Orange", rgb: [255, 146, 64] },
    { id: "yellow", label: "Yellow", rgb: [255, 214, 77] },
  ];
}

function applyTheme(id) {
  const t = themes().find((x) => x.id === id) || themes()[1];
  state.theme = t.id;
  const root = document.documentElement;
  root.style.setProperty("--accent", `rgb(${t.rgb[0]},${t.rgb[1]},${t.rgb[2]})`);
  root.style.setProperty("--accent2", `rgba(${t.rgb[0]},${t.rgb[1]},${t.rgb[2]},.65)`);
  root.style.setProperty("--bg0", "#050607");
  root.style.setProperty("--bg1", "#000000");
  root.style.setProperty("--lime", "var(--accent)");
  root.style.setProperty("--lime2", "var(--accent)");
  document.body.style.background =
    `radial-gradient(650px 650px at 15% -10%, var(--accent2), transparent 60%),` +
    `radial-gradient(900px 900px at 110% 110%, rgba(0,0,0,.0), transparent 55%),` +
    `linear-gradient(135deg, var(--bg1), var(--bg0))`;

  localStorage.setItem("arac_theme", state.theme);
  renderThemes();
}

function renderThemes() {
  const menu = $("themeMenu");
  if (!menu) return;
  menu.innerHTML = "";
  for (const t of themes()) {
    const el = document.createElement("div");
    el.className = "opt" + (t.id === state.theme ? " active" : "");
    el.innerHTML = `<div class="optname"></div><div class="optswatch"></div>`;
    el.querySelector(".optname").textContent = t.label;
    const sw = el.querySelector(".optswatch");
    sw.style.background = `linear-gradient(135deg, rgba(${t.rgb[0]},${t.rgb[1]},${t.rgb[2]},.95), rgba(0,0,0,.10))`;
    el.onclick = () => {
      applyTheme(t.id);
      closeThemeMenu();
    };
    menu.appendChild(el);
  }

  const cur = themes().find((x) => x.id === state.theme) || themes()[1];
  $("themeLabel").textContent = cur.label;
}

function openThemeMenu() {
  const m = $("themeMenu");
  if (!m) return;
  m.hidden = false;
}

function closeThemeMenu() {
  const m = $("themeMenu");
  if (!m) return;
  m.hidden = true;
}

function toggleThemeMenu() {
  const m = $("themeMenu");
  if (!m) return;
  m.hidden ? openThemeMenu() : closeThemeMenu();
}

function updateVpnUi({ enabled, busy, status }) {
  if (typeof enabled === "boolean") state.vpnEnabled = enabled;
  if (typeof busy === "boolean") state.vpnBusy = busy;

  const toggle = $("vpnToggle");
  const statusEl = $("vpnStatus");
  if (!toggle || !statusEl) return;

  toggle.checked = state.vpnEnabled;
  toggle.disabled = state.vpnBusy;
  if (typeof status === "string" && status.length) statusEl.textContent = status;
}

async function onVpnToggleChanged() {
  if (state.vpnBusy) return;
  const toggle = $("vpnToggle");
  if (!toggle) return;

  const wanted = !!toggle.checked;
  const prev = state.vpnEnabled;
  updateVpnUi({
    enabled: prev,
    busy: true,
    status: wanted ? "Installing/connecting..." : "Disconnecting...",
  });

  try {
    const res = await send(wanted ? "vpn:enable" : "vpn:disable", {}, wanted ? 300000 : 45000);
    const data = res.data || {};
    const ok = !!data.ok;
    const enabled = !!data.enabled;
    const message = data.message || (enabled ? "VPN enabled." : "VPN disabled.");
    if (!ok) throw new Error(message);
    updateVpnUi({ enabled, busy: false, status: message });
    toast("VPN", message);
  } catch (err) {
    const msg = err && err.message ? err.message : (wanted ? "Failed to enable VPN." : "Failed to disable VPN.");
    updateVpnUi({ enabled: prev, busy: false, status: msg });
    toast("VPN", msg);
  }
}

async function attach() {
  $("hint").textContent = "Working...";
  const res = await send("executor:attach");
  if (!res.data.ok) $("hint").textContent = "Attach failed.";
  else $("hint").textContent = "Ready.";
}

async function execute() {
  const content = getEditorText();
  if (!content.trim()) return toast("Execute", "Empty script.");
  $("hint").textContent = "Working...";
  const res = await send("executor:execute", { content });
  $("hint").textContent = res.data.ok ? "Ready." : "Failed.";
  if (!res.data.ok) toast("Execute", "Failed.");
}

function setEditorText(s) {
  if (editor) editor.setValue(s || "");
  else $("code").value = s || "";
}

function getEditorText() {
  return editor ? editor.getValue() : ($("code").value || "");
}

function initMonaco() {
  if (!window.require) return Promise.reject(new Error("no_loader"));
  return new Promise((resolve) => {
    window.require.config({
      paths: { vs: "https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs" },
    });
    window.require(["vs/editor/editor.main"], () => {
      monaco.languages.register({ id: "lua" });
      window.require(["vs/basic-languages/lua/lua"], () => {
        const el = $("monaco");
        editor = monaco.editor.create(el, {
          value: $("code").value || "",
          language: "lua",
          theme: "vs-dark",
          automaticLayout: true,
          minimap: { enabled: false },
          fontFamily: "Consolas, 'Cascadia Mono', monospace",
          fontSize: 14,
          lineHeight: 20,
          scrollBeyondLastLine: false,
          renderLineHighlight: "line",
        });

        monaco.languages.registerCompletionItemProvider("lua", {
          provideCompletionItems: () => {
            const words = [
              "print",
              "wait",
              "HttpGet",
              "loadstring",
              "pcall",
              "pairs",
              "ipairs",
              "tostring",
              "tonumber",
              "string",
              "table",
              "math",
              "game",
            ];
            return {
              suggestions: words.map((w) => ({
                label: w,
                kind: monaco.languages.CompletionItemKind.Function,
                insertText: w,
              })),
            };
          },
        });

        resolve();
      });
    });
  });
}

async function getScriptCodeById(id) {
  const res = await send("scriptlytoria:code", { id });
  return res.data.code || "";
}

function setTab(which) {
  const editor = which === "editor";
  const search = which === "search";
  const settings = which === "settings";

  $("tabEditor").classList.toggle("active", editor);
  $("tabSearch").classList.toggle("active", search);
  $("tabSettings").classList.toggle("active", settings);

  $("panelEditor").hidden = !editor;
  $("panelSearch").hidden = !search;
  $("panelSettings").hidden = !settings;

  if (search && !state.searchLoaded) {
    state.searchLoaded = true;
    loadLatest();
  }
}

function renderSearch() {
  const box = $("searchResults");
  box.innerHTML = "";
  for (const s of state.searchResults) {
    const el = document.createElement("div");
    el.className = "card";
    const desc = s.description || "";
    const meta = [s.author, s.category, s.difficulty, s.view_count != null ? `${s.view_count} views` : ""]
      .filter(Boolean)
      .join(" - ");
    el.innerHTML = `<div class="t"></div><div class="d"></div><div class="m"></div><div class="row end" style="margin-top:10px; gap:8px"><button class="btn" data-act="load">Load to Editor</button><button class="btn primary" data-act="exec">Execute</button></div>`;
    el.querySelector(".t").textContent = s.name || "";
    el.querySelector(".d").textContent = desc;
    el.querySelector(".m").textContent = meta;

    const id = s.id;
    el.querySelector('[data-act="load"]').onclick = async (e) => {
      e.stopPropagation();
      try {
        $("hint").textContent = "Working...";
        const code = await getScriptCodeById(id);
        setEditorText(code);
        setTab("editor");
        $("hint").textContent = "Ready.";
        toast("Loaded", "Loaded to editor.");
      } catch {
        $("hint").textContent = "Failed.";
        toast("Load", "Failed.");
      }
    };
    el.querySelector('[data-act="exec"]').onclick = async (e) => {
      e.stopPropagation();
      try {
        $("hint").textContent = "Working...";
        const code = await getScriptCodeById(id);
        const res = await send("executor:execute", { content: code });
        $("hint").textContent = res.data.ok ? "Ready." : "Failed.";
        if (!res.data.ok) toast("Execute", "Failed.");
      } catch {
        $("hint").textContent = "Failed.";
        toast("Execute", "Failed.");
      }
    };

    box.appendChild(el);
  }
}

async function loadLatest() {
  $("searchStatus").textContent = "Loading latest scripts...";
  try {
    const r = await fetch(`${SCRIPTLYTORIA_BASE}/getlatestscripts`);
    const j = await r.json();
    state.searchResults = j.scripts || [];
    $("searchStatus").textContent = `Latest: ${state.searchResults.length}`;
    renderSearch();
  } catch {
    $("searchStatus").textContent = "Failed to load latest.";
  }
}

async function doSearch() {
  const q = ($("searchInput").value || "").trim();
  if (!q) return loadLatest();
  $("searchStatus").textContent = "Searching...";
  try {
    const r = await fetch(`${SCRIPTLYTORIA_BASE}/fetchscript?name=${encodeURIComponent(q)}`);
    const j = await r.json();
    state.searchResults = j.scripts || [];
    $("searchStatus").textContent = `Results: ${state.searchResults.length}`;
    renderSearch();
  } catch {
    $("searchStatus").textContent = "Search failed.";
  }
}

function wire() {
  $("tabEditor").onclick = () => setTab("editor");
  $("tabSearch").onclick = () => setTab("search");
  $("tabSettings").onclick = () => setTab("settings");

  $("attachBtn").onclick = attach;
  $("executeBtn").onclick = execute;
  $("copyDiscordBtn").onclick = () => send("discord:copy").catch(() => {});
  $("loadScriptBtn").onclick = async () => {
    try {
      const res = await send("scripts:openFile");
      setEditorText(res.data.content || "");
      toast("Loaded", "Script loaded.");
    } catch {
      toast("Load", "Cancelled.");
    }
  };
  $("saveScriptBtn").onclick = async () => {
    const content = getEditorText();
    try {
      await send("scripts:saveFile", { content });
    } catch {
      toast("Save", "Cancelled.");
    }
  };

  $("searchBtn").onclick = doSearch;
  $("latestBtn").onclick = loadLatest;
  $("searchInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") doSearch();
  });

  $("themeBtn").onclick = () => toggleThemeMenu();
  const vpnToggle = $("vpnToggle");
  if (vpnToggle) vpnToggle.addEventListener("change", onVpnToggleChanged);
  document.addEventListener("click", (e) => {
    const sel = $("themeSelect");
    const m = $("themeMenu");
    if (!sel || !m || m.hidden) return;
    if (!sel.contains(e.target)) closeThemeMenu();
  });
}

function onHostMessage(ev) {
  const msg = ev.data;
  if (!msg) return;

  if (msg.id && pending.has(msg.id)) {
    const p = pending.get(msg.id);
    pending.delete(msg.id);
    if (msg.ok) p.resolve(msg);
    else p.reject(new Error(msg.error || "error"));
    return;
  }

  if (msg.type === "toast") {
    toast(msg.payload?.title, msg.payload?.body);
  }
}

async function boot() {
  wire();
  updateVpnUi({ enabled: false, busy: false, status: "Disabled." });
  const saved = localStorage.getItem("arac_theme") || "green";
  applyTheme(saved);
  try { await initMonaco(); } catch { }
  if (hasHost()) {
    window.chrome.webview.addEventListener("message", onHostMessage);
    try {
      const res = await send("app:init");
      $("versionPill").textContent = `v${res.data.version || "?"}`;
      $("settingsVersion").textContent = `v${res.data.version || "?"}`;
      $("settingsVersion2").textContent = `v${res.data.version || "?"}`;
      setTab("editor");
    } catch {
    }
  } else {
    toast("Host", "WebView2 host not available.");
  }
}

boot();
