using Microsoft.Web.WebView2.Core;
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace PolytoriaExecutor
{
    public partial class MainWindow : Window
    {
        private const string UI_VERSION = "1.0.6";

        private const string DLL_NAME = "polytoria_interface.dll";
        private const string PIPE_NAME = "PolytoriaPipe";
        private const string TARGET_PROCESS = "Polytoria Client";

        private const string ARACPROTECT_BASE = "https://aracnideoex.onrender.com";
        private const string ARACPROTECT_INITIALIZE_PATH = "/api/initialize";
        private const string DISCORD_INVITE = "https://discord.gg/y7bCWxpT";
        private const string UPDATE_INFO_URL = "https://raw.githubusercontent.com/arocimorr/Aracnideo-Executor/refs/heads/main/latest.txt";
        private const string WARP_WINGET_ID = "Cloudflare.Warp";
        private const string WARP_MSI_URL = "https://1111-releases.cloudflareclient.com/windows/Cloudflare_WARP_Release-x64.msi";
        private const string WARP_INSTALL_WARNING = "Warning: This VPN feature uses Cloudflare WARP software. We do not control its source code or integrity. Do you want to proceed with the installation?";

        private static readonly HttpClient _http = new(new HttpClientHandler { AutomaticDecompression = System.Net.DecompressionMethods.All })
        {
            Timeout = TimeSpan.FromSeconds(10)
        };

        private sealed class SessionInfo
        {
            public required string SessionId { get; init; }
            public required string Token { get; init; }
            public required byte[] SessionKey { get; init; }
        }

        private sealed class ScriptlytoriaAuth
        {
            public required string SupabaseUrl { get; init; }
            public required string AnonKey { get; init; }
        }

        private SessionInfo? _session;
        private bool _attached;
        private bool _webReady;
        private ScriptlytoriaAuth? _scriptlytoria;
        private readonly object _vpnSync = new();
        private bool _vpnOpInProgress;

        public MainWindow()
        {
            InitializeComponent();
            SetStatusNative("Not attached", ok: false, hint: "Ready.");
            Loaded += async (_, __) =>
            {
                try { await InitWebAsync(); }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Startup failed", MessageBoxButton.OK, MessageBoxImage.Error);
                    Close();
                    return;
                }

                try { await CheckForUpdatesAsync(); }
                catch { }
            };
        }

        private async System.Threading.Tasks.Task InitWebAsync()
        {
            await web.EnsureCoreWebView2Async();
            web.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
            web.CoreWebView2.Settings.IsStatusBarEnabled = false;
            web.CoreWebView2.WebMessageReceived += WebMessageReceived;

            string uiDir = ExtractWebUiToTemp();
            web.CoreWebView2.SetVirtualHostNameToFolderMapping("aracnideo.local", uiDir, CoreWebView2HostResourceAccessKind.Allow);
            web.CoreWebView2.Navigate($"https://aracnideo.local/index.html?v={UI_VERSION}&t={DateTime.UtcNow.Ticks}");
            _webReady = true;
        }

        private string ExtractWebUiToTemp()
        {
            string dir = Path.Combine(Path.GetTempPath(), "AracnideoExecutor", "webui", UI_VERSION);
            Directory.CreateDirectory(dir);
            ExtractRes("AracnideoExecutor.webui.index.html", Path.Combine(dir, "index.html"));
            ExtractRes("AracnideoExecutor.webui.app.js", Path.Combine(dir, "app.js"));
            ExtractRes("AracnideoExecutor.webui.styles.css", Path.Combine(dir, "styles.css"));
            return dir;
        }

        private static void ExtractRes(string resName, string path)
        {
            using Stream? s = Assembly.GetExecutingAssembly().GetManifestResourceStream(resName);
            if (s == null) throw new FileNotFoundException($"Embedded resource not found: {resName}");
            using var f = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Read);
            s.CopyTo(f);
        }

        private async System.Threading.Tasks.Task CheckForUpdatesAsync()
        {
            string body = await _http.GetStringAsync(UPDATE_INFO_URL);
            if (!TryParseLatestInfo(body, out string remoteVersion, out string downloadUrl)) return;
            if (!Version.TryParse(UI_VERSION, out Version? current)) return;
            if (!Version.TryParse(remoteVersion, out Version? latest)) return;
            if (latest <= current) return;

            bool shouldDownload = await Dispatcher.InvokeAsync(() =>
            {
                string msg =
                    "There is an update avaiable do you want to download it?" + Environment.NewLine +
                    $"Current Version: {UI_VERSION}" + Environment.NewLine +
                    $"New version: {remoteVersion}";
                return MessageBox.Show(msg, "Update Available", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes;
            });
            if (!shouldDownload) return;

            await DownloadAndApplyUpdateAsync(remoteVersion, downloadUrl);
        }

        private static bool TryParseLatestInfo(string text, out string version, out string link)
        {
            version = "";
            link = "";
            if (string.IsNullOrWhiteSpace(text)) return false;

            string[] lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.StartsWith("v=", StringComparison.OrdinalIgnoreCase))
                {
                    version = line[2..].Trim();
                    continue;
                }
                if (line.StartsWith("link=", StringComparison.OrdinalIgnoreCase))
                {
                    link = line[5..].Trim();
                    continue;
                }
            }

            return !string.IsNullOrWhiteSpace(version) && !string.IsNullOrWhiteSpace(link);
        }

        private async System.Threading.Tasks.Task DownloadAndApplyUpdateAsync(string newVersion, string downloadUrl)
        {
            string? currentExePath = Process.GetCurrentProcess().MainModule?.FileName;
            if (string.IsNullOrWhiteSpace(currentExePath) || !File.Exists(currentExePath))
            {
                await Dispatcher.InvokeAsync(() =>
                    MessageBox.Show("Could not resolve current executable path.", "Update failed", MessageBoxButton.OK, MessageBoxImage.Error));
                return;
            }

            string currentDir = Path.GetDirectoryName(currentExePath) ?? AppDomain.CurrentDomain.BaseDirectory;
            string normalizedVersion = newVersion.Replace('.', '-');
            string newExeName = $"Aracnideo-Executor-{normalizedVersion}.exe";
            string newExePath = Path.Combine(currentDir, newExeName);
            if (string.Equals(newExePath, currentExePath, StringComparison.OrdinalIgnoreCase))
                newExePath = Path.Combine(currentDir, $"Aracnideo-Executor-{normalizedVersion}-new.exe");

            try
            {
                using var dl = new HttpClient(new HttpClientHandler { AutomaticDecompression = System.Net.DecompressionMethods.All })
                {
                    Timeout = TimeSpan.FromMinutes(15)
                };

                byte[] exeBytes = await dl.GetByteArrayAsync(downloadUrl);
                await File.WriteAllBytesAsync(newExePath, exeBytes);
            }
            catch (Exception ex)
            {
                await Dispatcher.InvokeAsync(() =>
                    MessageBox.Show($"Failed to download the update.{Environment.NewLine}{ex.Message}", "Update failed", MessageBoxButton.OK, MessageBoxImage.Error));
                return;
            }

            LaunchUpdateScript(newExePath, currentExePath, Process.GetCurrentProcess().Id);
            await Dispatcher.InvokeAsync(() => Application.Current.Shutdown());
        }

        private static void LaunchUpdateScript(string newExePath, string oldExePath, int currentPid)
        {
            string scriptPath = Path.Combine(Path.GetTempPath(), $"aracnideo_update_{Guid.NewGuid():N}.cmd");
            string script =
                "@echo off" + Environment.NewLine +
                "setlocal" + Environment.NewLine +
                $"set \"NEW_EXE={newExePath}\"" + Environment.NewLine +
                $"set \"OLD_EXE={oldExePath}\"" + Environment.NewLine +
                $"set \"TARGET_PID={currentPid}\"" + Environment.NewLine +
                ":waitloop" + Environment.NewLine +
                "tasklist /FI \"PID eq %TARGET_PID%\" 2>NUL | find \"%TARGET_PID%\" >NUL" + Environment.NewLine +
                "if not errorlevel 1 (" + Environment.NewLine +
                "  timeout /t 1 /nobreak >NUL" + Environment.NewLine +
                "  goto waitloop" + Environment.NewLine +
                ")" + Environment.NewLine +
                "del /f /q \"%OLD_EXE%\" >NUL 2>&1" + Environment.NewLine +
                "start \"\" \"%NEW_EXE%\"" + Environment.NewLine +
                "del /f /q \"%~f0\" >NUL 2>&1";

            File.WriteAllText(scriptPath, script, new UTF8Encoding(false));
            Process.Start(new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/c \"{scriptPath}\"",
                UseShellExecute = false,
                CreateNoWindow = true
            });
        }

        private async void WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                using JsonDocument doc = JsonDocument.Parse(e.WebMessageAsJson);
                JsonElement root = doc.RootElement;
                string id = root.GetProperty("id").GetString() ?? "";
                string type = root.GetProperty("type").GetString() ?? "";
                JsonElement payload = root.TryGetProperty("payload", out var p) ? p : default;
                if (id.Length == 0 || type.Length == 0) return;

                switch (type)
                {
                    case "app:init":
                        await ReplyOkAsync(id, new { version = UI_VERSION, attached = _attached });
                        return;
                    case "window:minimize":
                        Dispatcher.Invoke(() => WindowState = WindowState.Minimized);
                        await ReplyOkAsync(id, new { });
                        return;
                    case "window:close":
                        Dispatcher.Invoke(Close);
                        await ReplyOkAsync(id, new { });
                        return;
                    case "window:maximizeToggle":
                        Dispatcher.Invoke(() => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized);
                        await ReplyOkAsync(id, new { });
                        return;
                    case "discord:copy":
                        try { Clipboard.SetText(DISCORD_INVITE); } catch { }
                        await SendEventAsync("toast", new { title = "Discord", body = "Link copied." });
                        await ReplyOkAsync(id, new { });
                        return;
                    case "scripts:openFile":
                        {
                            string? path = await Dispatcher.InvokeAsync(OpenLuaFileDialog);
                            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
                            {
                                await ReplyErrAsync(id, "cancelled");
                                return;
                            }
                            string content = File.ReadAllText(path, Encoding.UTF8);
                            await ReplyOkAsync(id, new { path, content });
                            return;
                        }
                    case "scripts:saveFile":
                        {
                            string content = payload.ValueKind == JsonValueKind.Object && payload.TryGetProperty("content", out var cEl) && cEl.ValueKind == JsonValueKind.String ? (cEl.GetString() ?? "") : "";
                            string? path = await Dispatcher.InvokeAsync(() => SaveLuaFileDialog());
                            if (string.IsNullOrWhiteSpace(path))
                            {
                                await ReplyErrAsync(id, "cancelled");
                                return;
                            }
                            File.WriteAllText(path, content, new UTF8Encoding(false));
                            await SendEventAsync("toast", new { title = "Saved", body = Path.GetFileName(path) });
                            await ReplyOkAsync(id, new { path });
                            return;
                        }
                    case "executor:attach":
                        {
                            bool ok = await System.Threading.Tasks.Task.Run(AttachOnce);
                            await ReplyOkAsync(id, new { ok, attached = _attached });
                            return;
                        }
                    case "executor:execute":
                        {
                            string content = payload.GetProperty("content").GetString() ?? "";
                            bool ok = await System.Threading.Tasks.Task.Run(() => ExecuteOnce(content));
                            await ReplyOkAsync(id, new { ok });
                            return;
                        }
                    case "scriptlytoria:code":
                        {
                            string scriptId = payload.ValueKind == JsonValueKind.Object && payload.TryGetProperty("id", out var sEl) && sEl.ValueKind == JsonValueKind.String ? (sEl.GetString() ?? "") : "";
                            if (string.IsNullOrWhiteSpace(scriptId))
                            {
                                await ReplyErrAsync(id, "invalid_id");
                                return;
                            }

                            string code = await System.Threading.Tasks.Task.Run(() => FetchScriptlytoriaCode(scriptId));
                            await ReplyOkAsync(id, new { id = scriptId, code });
                            return;
                        }
                    case "vpn:enable":
                        {
                            if (!TryBeginVpnOp())
                            {
                                await ReplyOkAsync(id, new { ok = false, enabled = false, message = "VPN operation already in progress." });
                                return;
                            }

                            try
                            {
                                var result = await System.Threading.Tasks.Task.Run(EnableVpnFlow);
                                await ReplyOkAsync(id, new { ok = result.ok, enabled = result.enabled, message = result.message });
                                return;
                            }
                            finally
                            {
                                EndVpnOp();
                            }
                        }
                    case "vpn:disable":
                        {
                            if (!TryBeginVpnOp())
                            {
                                await ReplyOkAsync(id, new { ok = false, enabled = true, message = "VPN operation already in progress." });
                                return;
                            }

                            try
                            {
                                var result = await System.Threading.Tasks.Task.Run(DisableVpnFlow);
                                await ReplyOkAsync(id, new { ok = result.ok, enabled = result.enabled, message = result.message });
                                return;
                            }
                            finally
                            {
                                EndVpnOp();
                            }
                        }
                }

                await ReplyErrAsync(id, "unknown_type");
            }
            catch
            {
            }
        }

        private static string? OpenLuaFileDialog()
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Lua scripts (*.lua)|*.lua|All files (*.*)|*.*",
                Title = "Open Script"
            };
            bool? ok = dlg.ShowDialog();
            return ok == true ? dlg.FileName : null;
        }

        private static string? SaveLuaFileDialog()
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "Lua scripts (*.lua)|*.lua|All files (*.*)|*.*",
                Title = "Save Script",
                DefaultExt = ".lua",
                AddExtension = true
            };
            bool? ok = dlg.ShowDialog();
            return ok == true ? dlg.FileName : null;
        }

        private async System.Threading.Tasks.Task SendEventAsync(string type, object payload)
        {
            if (!_webReady || web.CoreWebView2 == null) return;
            string json = JsonSerializer.Serialize(new { type, payload });
            await Dispatcher.InvokeAsync(() => web.CoreWebView2.PostWebMessageAsJson(json));
        }

        private async System.Threading.Tasks.Task ReplyOkAsync(string id, object data)
        {
            string json = JsonSerializer.Serialize(new { id, ok = true, data });
            await Dispatcher.InvokeAsync(() => web.CoreWebView2.PostWebMessageAsJson(json));
        }

        private async System.Threading.Tasks.Task ReplyErrAsync(string id, string error)
        {
            string json = JsonSerializer.Serialize(new { id, ok = false, error });
            await Dispatcher.InvokeAsync(() => web.CoreWebView2.PostWebMessageAsJson(json));
        }

        private bool TryBeginVpnOp()
        {
            lock (_vpnSync)
            {
                if (_vpnOpInProgress) return false;
                _vpnOpInProgress = true;
                return true;
            }
        }

        private void EndVpnOp()
        {
            lock (_vpnSync) _vpnOpInProgress = false;
        }

        private (bool ok, bool enabled, string message) EnableVpnFlow()
        {
            try
            {
                if (!EnsureWarpCliInstalled(out string warpCliPath, out string installMessage))
                    return (false, false, installMessage);

                EnsureWarpRegistration(warpCliPath);

                if (!RunProcess(warpCliPath, "connect", 60000, out int exitCode, out string output))
                    return (false, false, $"Failed to connect Cloudflare WARP: {output}");

                if (exitCode == 0 || output.Contains("already connected", StringComparison.OrdinalIgnoreCase) || output.Contains("connected", StringComparison.OrdinalIgnoreCase))
                    return (true, true, "VPN enabled (Cloudflare WARP).");

                return (false, false, $"Failed to connect Cloudflare WARP: {NormalizeOutput(output)}");
            }
            catch (Exception ex)
            {
                return (false, false, $"Failed to enable VPN: {ex.Message}");
            }
        }

        private (bool ok, bool enabled, string message) DisableVpnFlow()
        {
            try
            {
                string? warpCliPath = ResolveWarpCliPath();
                if (string.IsNullOrWhiteSpace(warpCliPath))
                    return (true, false, "VPN disabled.");

                if (!RunProcess(warpCliPath, "disconnect", 45000, out int exitCode, out string output))
                    return (false, true, $"Failed to disconnect Cloudflare WARP: {output}");

                if (exitCode == 0
                    || output.Contains("not connected", StringComparison.OrdinalIgnoreCase)
                    || output.Contains("already disconnected", StringComparison.OrdinalIgnoreCase)
                    || output.Contains("disconnected", StringComparison.OrdinalIgnoreCase))
                {
                    return (true, false, "VPN disabled.");
                }

                return (false, true, $"Failed to disconnect Cloudflare WARP: {NormalizeOutput(output)}");
            }
            catch (Exception ex)
            {
                return (false, true, $"Failed to disable VPN: {ex.Message}");
            }
        }

        private bool EnsureWarpCliInstalled(out string warpCliPath, out string message)
        {
            warpCliPath = ResolveWarpCliPath() ?? "";
            if (!string.IsNullOrWhiteSpace(warpCliPath))
            {
                message = "Cloudflare WARP already installed.";
                return true;
            }

            bool proceed = Dispatcher.Invoke(() =>
            {
                MessageBoxResult result = MessageBox.Show(
                    WARP_INSTALL_WARNING,
                    "Cloudflare WARP Installation",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);
                return result == MessageBoxResult.Yes;
            });

            if (!proceed)
            {
                message = "Installation cancelled.";
                return false;
            }

            string installError = "";
            bool installed = InstallWarpViaWinget(out installError);
            if (!installed) installed = InstallWarpViaMsi(out installError);
            if (!installed)
            {
                message = $"Failed to install Cloudflare WARP: {installError}";
                return false;
            }

            for (int i = 0; i < 10; i++)
            {
                warpCliPath = ResolveWarpCliPath() ?? "";
                if (!string.IsNullOrWhiteSpace(warpCliPath))
                {
                    message = "Cloudflare WARP installed.";
                    return true;
                }
                Thread.Sleep(1000);
            }

            message = "Cloudflare WARP installer finished, but warp-cli was not found.";
            return false;
        }

        private static bool InstallWarpViaWinget(out string error)
        {
            string args =
                $"install --id {WARP_WINGET_ID} -e --source winget --accept-package-agreements --accept-source-agreements --silent --disable-interactivity";
            if (!RunProcess("winget", args, 300000, out int exitCode, out string output))
            {
                error = output;
                return false;
            }

            if (exitCode != 0)
            {
                error = NormalizeOutput(output);
                return false;
            }

            error = "";
            return true;
        }

        private static bool InstallWarpViaMsi(out string error)
        {
            string tempFile = Path.Combine(Path.GetTempPath(), $"cloudflare_warp_{Guid.NewGuid():N}.msi");
            try
            {
                byte[] bytes = _http.GetByteArrayAsync(WARP_MSI_URL).GetAwaiter().GetResult();
                File.WriteAllBytes(tempFile, bytes);

                string args = $"/i \"{tempFile}\" /passive /norestart";
                if (!RunProcess("msiexec.exe", args, 300000, out int exitCode, out string output))
                {
                    error = output;
                    return false;
                }

                if (exitCode != 0)
                {
                    error = NormalizeOutput(output);
                    return false;
                }

                error = "";
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
            finally
            {
                try
                {
                    if (File.Exists(tempFile)) File.Delete(tempFile);
                }
                catch { }
            }
        }

        private static void EnsureWarpRegistration(string warpCliPath)
        {
            string[] attempts =
            {
                "registration new",
                "--accept-tos registration new",
                "register",
                "--accept-tos register"
            };

            foreach (string args in attempts)
            {
                if (!RunProcess(warpCliPath, args, 60000, out int exitCode, out string output)) continue;
                if (exitCode == 0) return;
                if (output.Contains("already", StringComparison.OrdinalIgnoreCase) &&
                    output.Contains("register", StringComparison.OrdinalIgnoreCase)) return;
                if (output.Contains("registered", StringComparison.OrdinalIgnoreCase)) return;
            }
        }

        private static string? ResolveWarpCliPath()
        {
            if (RunProcess("where.exe", "warp-cli.exe", 8000, out int whereExit, out string whereOutput) && whereExit == 0)
            {
                string first = whereOutput
                    .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => x.Trim())
                    .FirstOrDefault(x => x.EndsWith("warp-cli.exe", StringComparison.OrdinalIgnoreCase) && File.Exists(x)) ?? "";
                if (!string.IsNullOrWhiteSpace(first)) return first;
            }

            string[] knownPaths =
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Cloudflare", "Cloudflare WARP", "warp-cli.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Cloudflare", "Cloudflare WARP", "warp-cli.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Cloudflare", "Cloudflare WARP", "warp-cli.exe")
            };

            return knownPaths.FirstOrDefault(File.Exists);
        }

        private static bool RunProcess(string fileName, string args, int timeoutMs, out int exitCode, out string output)
        {
            output = "";
            exitCode = -1;

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = args,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using var proc = Process.Start(psi);
                if (proc == null)
                {
                    output = $"Failed to start process: {fileName}";
                    return false;
                }

                System.Threading.Tasks.Task<string> stdOut = proc.StandardOutput.ReadToEndAsync();
                System.Threading.Tasks.Task<string> stdErr = proc.StandardError.ReadToEndAsync();

                if (!proc.WaitForExit(timeoutMs))
                {
                    try { proc.Kill(true); } catch { }
                    output = $"{fileName} timed out.";
                    return false;
                }

                System.Threading.Tasks.Task.WaitAll(new System.Threading.Tasks.Task[] { stdOut, stdErr }, 1000);
                exitCode = proc.ExitCode;

                string outText = stdOut.IsCompletedSuccessfully ? stdOut.Result : "";
                string errText = stdErr.IsCompletedSuccessfully ? stdErr.Result : "";
                output = $"{outText}\n{errText}".Trim();
                return true;
            }
            catch (Exception ex)
            {
                output = ex.Message;
                return false;
            }
        }

        private static string NormalizeOutput(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "Unknown error.";
            string trimmed = value.Trim();
            return trimmed.Length <= 220 ? trimmed : trimmed[..220];
        }

        private bool AttachOnce()
        {
            try
            {
                SetStatusNative("Attaching...", ok: true, hint: "Working...");
                _session = InitializeSession();
                Process[] targetProcess = Process.GetProcessesByName(TARGET_PROCESS);
                if (targetProcess.Length == 0)
                {
                    _attached = false;
                    SetStatusNative("Not attached", ok: false, hint: "Not running.");
                    _ = SendEventAsync("toast", new { title = "Attach", body = "Target process not running." });
                    return false;
                }

                int procId = targetProcess[0].Id;
                string dllPath = Path.GetFullPath(ResolveDllPath());
                if (!InjectDLL(procId, dllPath, out _))
                {
                    _attached = false;
                    SetStatusNative("Not attached", ok: false, hint: "Failed.");
                    _ = SendEventAsync("toast", new { title = "Attach", body = "Failed." });
                    return false;
                }

                _attached = true;
                SetStatusNative("Attached", ok: true, hint: "Ready.");
                try { if (_session != null) HandshakePipeSession(_session); } catch { }
                _ = SendEventAsync("toast", new { title = "Attach", body = "Attached." });
                return true;
            }
            catch
            {
                _attached = false;
                SetStatusNative("Not attached", ok: false, hint: "Failed.");
                _ = SendEventAsync("toast", new { title = "Attach", body = "Failed." });
                return false;
            }
        }

        private bool ExecuteOnce(string script)
        {
            try
            {
                if (_session == null) return false;
                if (string.IsNullOrWhiteSpace(script)) return false;
                SetStatusNative("Executing...", ok: true, hint: "Working...");

                using var client = new NamedPipeClientStream(".", PIPE_NAME, PipeDirection.InOut);
                client.Connect(1000);
                client.ReadMode = PipeTransmissionMode.Message;

                string payload = BuildEncryptedExecMessage(_session, script);
                byte[] bytes = Encoding.UTF8.GetBytes(payload);
                client.Write(bytes, 0, bytes.Length);
                client.Flush();

                using var reader = new StreamReader(client, Encoding.UTF8, leaveOpen: true);
                string? resp = ReadLineWithTimeout(reader, 2000);
                if (string.IsNullOrWhiteSpace(resp)) return false;
                if (resp.StartsWith("ERR:", StringComparison.OrdinalIgnoreCase)) return false;
                SetStatusNative("Ready", ok: true, hint: "Ready.");
                return true;
            }
            catch
            {
                SetStatusNative("Failed", ok: false, hint: "Failed.");
                return false;
            }
        }

        private string FetchScriptlytoriaCode(string scriptId)
        {
            try
            {
                var auth = _scriptlytoria ??= FetchScriptlytoriaAuth();
                return FetchScriptlytoriaCodeWithAuth(auth, scriptId);
            }
            catch
            {
                _scriptlytoria = null;
                var auth = _scriptlytoria ??= FetchScriptlytoriaAuth();
                return FetchScriptlytoriaCodeWithAuth(auth, scriptId);
            }
        }

        private static ScriptlytoriaAuth FetchScriptlytoriaAuth()
        {
            var baseUri = new Uri("https://scriptlytoria.lovable.app/");
            string html = _http.GetStringAsync(new Uri(baseUri, "/")).GetAwaiter().GetResult();

            var m = System.Text.RegularExpressions.Regex.Match(html, "<script[^>]+type=\"module\"[^>]+src=\"([^\"]+)\"", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (!m.Success)
                throw new InvalidOperationException("bundle_not_found");

            string src = m.Groups[1].Value;
            Uri bundleUrl = new Uri(baseUri, src);
            string bundleJs = _http.GetStringAsync(bundleUrl).GetAwaiter().GetResult();

            var sm = System.Text.RegularExpressions.Regex.Match(bundleJs, "https://[a-z0-9-]+\\.supabase\\.co", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (!sm.Success)
                throw new InvalidOperationException("supabase_url_not_found");

            string supabaseUrl = sm.Value;
            var keys = System.Text.RegularExpressions.Regex.Matches(bundleJs, "eyJ[A-Za-z0-9_\\-]+\\.[A-Za-z0-9_\\-]+\\.[A-Za-z0-9_\\-]+");
            if (keys.Count == 0)
                throw new InvalidOperationException("anon_key_not_found");

            string anonKey = keys.Cast<System.Text.RegularExpressions.Match>().OrderByDescending(x => x.Value.Length).First().Value;

            return new ScriptlytoriaAuth
            {
                SupabaseUrl = supabaseUrl,
                AnonKey = anonKey
            };
        }

        private static string FetchScriptlytoriaCodeWithAuth(ScriptlytoriaAuth auth, string scriptId)
        {
            var uri = new Uri($"{auth.SupabaseUrl}/rest/v1/scripts?id=eq.{Uri.EscapeDataString(scriptId)}&select=code");
            using var req = new HttpRequestMessage(HttpMethod.Get, uri);
            req.Headers.TryAddWithoutValidation("apikey", auth.AnonKey);
            req.Headers.TryAddWithoutValidation("Authorization", $"Bearer {auth.AnonKey}");

            using HttpResponseMessage resp = _http.Send(req);
            string body = resp.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            if (!resp.IsSuccessStatusCode)
                throw new InvalidOperationException($"http_{(int)resp.StatusCode}");

            using JsonDocument doc = JsonDocument.Parse(body);
            if (doc.RootElement.ValueKind != JsonValueKind.Array || doc.RootElement.GetArrayLength() == 0)
                throw new InvalidOperationException("not_found");

            JsonElement first = doc.RootElement[0];
            if (!first.TryGetProperty("code", out var cEl) || cEl.ValueKind != JsonValueKind.String)
                throw new InvalidOperationException("no_code");

            return cEl.GetString() ?? "";
        }

        private SessionInfo InitializeSession()
        {
            var payload = new { clientVersion = Assembly.GetExecutingAssembly().GetName().Version?.ToString(), machine = Environment.MachineName };
            using var req = new HttpRequestMessage(HttpMethod.Post, new Uri(new Uri(ARACPROTECT_BASE), ARACPROTECT_INITIALIZE_PATH));
            req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            using HttpResponseMessage resp = _http.Send(req);
            string body = resp.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            if (!resp.IsSuccessStatusCode) throw new InvalidOperationException(body);

            using JsonDocument doc = JsonDocument.Parse(body);
            JsonElement root = doc.RootElement;
            if (!root.TryGetProperty("ok", out var okEl) || okEl.ValueKind != JsonValueKind.True) throw new InvalidOperationException(body);
            string sessionId = root.GetProperty("sessionId").GetString() ?? "";
            string token = root.GetProperty("token").GetString() ?? "";
            string keyB64 = root.GetProperty("sessionKeyB64").GetString() ?? "";
            byte[] key = Convert.FromBase64String(keyB64);
            if (key.Length != 32) throw new InvalidOperationException("bad_key");

            return new SessionInfo { SessionId = sessionId, Token = token, SessionKey = key };
        }

        private void HandshakePipeSession(SessionInfo session)
        {
            var deadline = DateTime.UtcNow.AddSeconds(4);
            while (DateTime.UtcNow < deadline)
            {
                try
                {
                    using var client = new NamedPipeClientStream(".", PIPE_NAME, PipeDirection.InOut);
                    client.Connect(500);
                    client.ReadMode = PipeTransmissionMode.Message;
                    byte[] helloBytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new
                    {
                        type = "hello",
                        v = 1,
                        sessionId = session.SessionId,
                        token = session.Token,
                        sessionKeyB64 = Convert.ToBase64String(session.SessionKey),
                    }));
                    client.Write(helloBytes, 0, helloBytes.Length);
                    client.Flush();
                    using var reader = new StreamReader(client, Encoding.UTF8, leaveOpen: true);
                    string? resp = ReadLineWithTimeout(reader, 1200);
                    if (!string.IsNullOrWhiteSpace(resp) && resp.StartsWith("OK", StringComparison.OrdinalIgnoreCase)) return;
                }
                catch
                {
                    Thread.Sleep(200);
                }
            }
        }

        private static string BuildEncryptedExecMessage(SessionInfo session, string script)
        {
            byte[] nonce = RandomNumberGenerator.GetBytes(12);
            byte[] pt = Encoding.UTF8.GetBytes(script);
            byte[] ct = new byte[pt.Length];
            byte[] tag = new byte[16];
            byte[] aad = Encoding.UTF8.GetBytes(session.SessionId);
            using (var gcm = new AesGcm(session.SessionKey, 16)) gcm.Encrypt(nonce, pt, ct, tag, aad);
            return JsonSerializer.Serialize(new
            {
                type = "exec",
                v = 1,
                sessionId = session.SessionId,
                nonceB64 = Convert.ToBase64String(nonce),
                ctB64 = Convert.ToBase64String(ct),
                tagB64 = Convert.ToBase64String(tag),
            });
        }

        private string ResolveDllPath()
        {
            string marker = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "polytoria_interface.latest.txt");
            if (File.Exists(marker))
            {
                try
                {
                    string path = File.ReadAllText(marker).Trim();
                    if (!Path.IsPathRooted(path)) path = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path));
                    if (File.Exists(path)) return path;
                }
                catch { }
            }

            string local = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, DLL_NAME);
            if (File.Exists(local)) return local;
            return ExtractEmbeddedDllToTemp();
        }

        private static string ExtractEmbeddedDllToTemp()
        {
            const string resName = "AracnideoExecutor.polytoria_interface.dll";
            using Stream? s = Assembly.GetExecutingAssembly().GetManifestResourceStream(resName);
            if (s == null) throw new FileNotFoundException($"Embedded resource not found: {resName}");
            string dir = Path.Combine(Path.GetTempPath(), "AracnideoExecutor");
            Directory.CreateDirectory(dir);
            string path = Path.Combine(dir, $"polytoria_interface_{DateTime.UtcNow.Ticks}.dll");
            using (var f = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Read)) s.CopyTo(f);
            return path;
        }

        private static string? ReadLineWithTimeout(StreamReader reader, int timeoutMs)
        {
            try
            {
                var t = System.Threading.Tasks.Task.Run(() => reader.ReadLine());
                return t.Wait(timeoutMs) ? t.Result : null;
            }
            catch { return null; }
        }

        private void SetStatusNative(string text, bool ok, string hint)
        {
            Dispatcher.Invoke(() =>
            {
                lblStatus.Text = text;
                lblHint.Text = hint;
                StatusDot.Fill = new SolidColorBrush(ok ? Color.FromRgb(0xB6, 0xFF, 0x1A) : Color.FromRgb(0xFF, 0x4D, 0x4D));
            });
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void btnClose_Click(object sender, RoutedEventArgs e) => Close();

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
                return;
            }
            DragMove();
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out int lpNumberOfBytesWritten);

        [DllImport("kernel32.dll")]
        private static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr hObject);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetExitCodeThread(IntPtr hThread, out uint lpExitCode);

        private const int PROCESS_CREATE_THREAD = 0x0002;
        private const int PROCESS_QUERY_INFORMATION = 0x0400;
        private const int PROCESS_VM_OPERATION = 0x0008;
        private const int PROCESS_VM_WRITE = 0x0020;
        private const int PROCESS_VM_READ = 0x0010;

        private const uint MEM_COMMIT = 0x00001000;
        private const uint MEM_RESERVE = 0x00002000;
        private const uint PAGE_READWRITE = 0x04;

        private const uint WAIT_OBJECT_0 = 0x00000000;
        private const uint WAIT_TIMEOUT = 0x00000102;
        private const uint INFINITE = 0xFFFFFFFF;

        private static string Win32Error(string prefix) => $"{prefix}. Win32Error={Marshal.GetLastWin32Error()}";

        private static bool InjectDLL(int procId, string dllPath, out string resultMessage)
        {
            IntPtr hProcess = IntPtr.Zero;
            IntPtr hThread = IntPtr.Zero;

            try
            {
                hProcess = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, false, procId);
                if (hProcess == IntPtr.Zero) { resultMessage = Win32Error("OpenProcess failed"); return false; }

                IntPtr loadLibraryAddr = GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA");
                if (loadLibraryAddr == IntPtr.Zero) { resultMessage = Win32Error("GetProcAddress failed"); return false; }

                byte[] dllBytes = Encoding.ASCII.GetBytes(dllPath + "\0");
                IntPtr alloc = VirtualAllocEx(hProcess, IntPtr.Zero, (uint)dllBytes.Length, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
                if (alloc == IntPtr.Zero) { resultMessage = Win32Error("VirtualAllocEx failed"); return false; }

                if (!WriteProcessMemory(hProcess, alloc, dllBytes, (uint)dllBytes.Length, out int written) || written != dllBytes.Length)
                { resultMessage = Win32Error("WriteProcessMemory failed"); return false; }

                hThread = CreateRemoteThread(hProcess, IntPtr.Zero, 0, loadLibraryAddr, alloc, 0, IntPtr.Zero);
                if (hThread == IntPtr.Zero) { resultMessage = Win32Error("CreateRemoteThread failed"); return false; }

                uint wait = WaitForSingleObject(hThread, INFINITE);
                if (wait != WAIT_OBJECT_0 && wait != WAIT_TIMEOUT) { resultMessage = Win32Error("WaitForSingleObject failed"); return false; }

                if (!GetExitCodeThread(hThread, out uint exitCode)) { resultMessage = Win32Error("GetExitCodeThread failed"); return false; }
                if (exitCode == 0) { resultMessage = "LoadLibraryA returned NULL"; return false; }

                resultMessage = "Injected OK";
                return true;
            }
            finally
            {
                if (hThread != IntPtr.Zero) CloseHandle(hThread);
                if (hProcess != IntPtr.Zero) CloseHandle(hProcess);
            }
        }
    }
}
