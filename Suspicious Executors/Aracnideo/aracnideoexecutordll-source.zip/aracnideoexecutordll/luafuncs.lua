math.randomseed(os.clock() * 1000000)

local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

local SEP = "~"
local PREFIX = "ARAC"

local function randomString(len)
  local s = {}
  for i = 1, len do
    local idx = math.random(1, #chars)
    s[i] = string.sub(chars, idx, idx)
  end
  return table.concat(s)
end

local b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local function b64enc(data)
  local bytes = { string.byte(data, 1, #data) }
  local out = {}
  local i = 1
  while i <= #bytes do
    local a = bytes[i] or 0
    local b = bytes[i + 1] or 0
    local c = bytes[i + 2] or 0
    local n = a * 65536 + b * 256 + c
    local s1 = math.floor(n / 262144) % 64 + 1
    local s2 = math.floor(n / 4096) % 64 + 1
    local s3 = math.floor(n / 64) % 64 + 1
    local s4 = n % 64 + 1
    out[#out + 1] = string.sub(b64chars, s1, s1)
    out[#out + 1] = string.sub(b64chars, s2, s2)
    out[#out + 1] = (i + 1 <= #bytes) and string.sub(b64chars, s3, s3) or "="
    out[#out + 1] = (i + 2 <= #bytes) and string.sub(b64chars, s4, s4) or "="
    i = i + 3
  end
  return table.concat(out)
end

local function call_native_wr(cmdPrefix)
  local id = randomString(20)
  local valueName = "AracWR_" .. id
  local requestfunction = cmdPrefix .. SEP .. b64enc(valueName)

  local pg = game["PlayerGUI"]
  local t0 = os.clock()
  while true do
    local folder = pg:FindChild("ClientValues")
    if folder then
      local v = folder:FindChild(valueName)
      if v and type(v.Value) == "string" then
        local out = v.Value
        if v.Destroy then
          v:Destroy()
        end
        return out
      end
    end

    if os.clock() - t0 > 60 then
      error("native WR timed out waiting for response", 3)
    end
    wait(3)
  end
end

local function call_native_nwr(cmd)
  local requestfunction = cmd
end

function __native_httpget(_self, url)
  if url == nil and type(_self) == "string" then
    url = _self
  end
  if type(url) ~= "string" then
    error("HttpGet: url must be a string", 2)
  end

  local id = randomString(20)
  local valueName = "HttpGet_" .. id

  local cmd = PREFIX .. SEP .. "HTTPGET" .. SEP .. b64enc(url)
  local requestfunction = cmd .. SEP .. b64enc(valueName)

  local pg = game["PlayerGUI"]
  local folder = pg:FindChild("ClientValues")

  local t0 = os.clock()
  while true do
    folder = folder or pg:FindChild("ClientValues")
    if folder then
      local v = folder:FindChild(valueName)
      if v and type(v.Value) == "string" then
        local out = v.Value
        if v.Destroy then
          v:Destroy()
        end
        return out
      end
    end

    if os.clock() - t0 > 60 then
      error("HttpGet: timed out waiting for native response", 2)
    end

    wait(3)
  end
end

function HttpGet(url)
  return __native_httpget(game, url)
end

function HttpPost(url, body, userAgent, timeoutMs)
  if type(url) ~= "string" then
    error("HttpPost: url must be a string", 2)
  end
  body = body or ""
  userAgent = userAgent or "aracnidea executor"
  timeoutMs = tonumber(timeoutMs or 0) or 0

  local cmd = PREFIX .. SEP .. "HTTPPOST" .. SEP .. b64enc(url) .. SEP .. b64enc(tostring(body)) .. SEP .. b64enc(tostring(userAgent)) .. SEP .. tostring(timeoutMs)
  return call_native_wr(cmd)
end

function writefile(filename, content)
  if type(filename) ~= "string" then
    error("writefile: filename must be a string", 2)
  end
  if type(content) ~= "string" then
    error("writefile: content must be a string", 2)
  end
  call_native_nwr(PREFIX .. SEP .. "WRITEFILE" .. SEP .. b64enc(filename) .. SEP .. b64enc(content))
end

function readfile(path)
  if type(path) ~= "string" then
    error("readfile: path must be a string", 2)
  end
  return call_native_wr(PREFIX .. SEP .. "READFILE" .. SEP .. b64enc(path))
end

function makefolder(path, foldername)
  path = path or ""
  foldername = foldername or ""
  if type(path) ~= "string" or type(foldername) ~= "string" then
    error("makefolder: args must be strings", 2)
  end
  local full = path
  if full ~= "" and string.sub(full, -1) ~= "/" and string.sub(full, -1) ~= "\\" then
    full = full .. "/"
  end
  full = full .. foldername
  call_native_nwr(PREFIX .. SEP .. "MAKEFOLDER" .. SEP .. b64enc(full))
end

function getfiles(path)
  path = path or ""
  if type(path) ~= "string" then
    error("getfiles: path must be a string", 2)
  end
  return call_native_wr(PREFIX .. SEP .. "GETFILES" .. SEP .. b64enc(path))
end

function delfile(path)
  if type(path) ~= "string" then
    error("delfile: path must be a string", 2)
  end
  call_native_nwr(PREFIX .. SEP .. "DELFILE" .. SEP .. b64enc(path))
end

function delfolder(path)
  if type(path) ~= "string" then
    error("delfolder: path must be a string", 2)
  end
  call_native_nwr(PREFIX .. SEP .. "DELFOLDER" .. SEP .. b64enc(path))
end

function loadstring(code)
  if type(code) ~= "string" then
    error("loadstring: code must be a string", 2)
  end
  return function()
    local requestfunction = PREFIX .. SEP .. "LOADSTRING" .. SEP .. b64enc(code)
  end
end
