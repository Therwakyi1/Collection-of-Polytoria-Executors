use std::env;
use std::fs;
use std::path::PathBuf;

fn xor_bytes(s: &str, key: u8) -> Vec<u8> {
    s.as_bytes().iter().map(|b| b ^ key).collect()
}

fn main() {
    let out_dir = PathBuf::from(env::var("OUT_DIR").unwrap());
    let key = 0xA7u8;

    // Keep names stable; referenced by include_bytes! in src/lib.rs.
    let items: &[(&str, &str)] = &[
        ("ga.bin", "GameAssembly.dll\0"),
        ("self.bin", "polytoria_interface.dll\0"),
        ("pipe.bin", "\\\\.\\pipe\\PolytoriaPipe"),
        ("asmcs.bin", "Assembly-CSharp"),
        ("ssname.bin", "ScriptService"),
        ("ssns.bin", "Polytoria.Datamodel.Services"),
        ("gamename.bin", "Game"),
        ("gamens.bin", "Polytoria.Datamodel"),
        ("siname.bin", "ScriptInstance"),
        ("singleton.bin", "singleton"),
        ("backing.bin", "<Instance>k__BackingField"),
        ("ucore.bin", "UnityEngine.CoreModule"),
        ("unityns.bin", "UnityEngine"),
        ("comp.bin", "Component"),
        ("getgo.bin", "get_gameObject"),
        ("gobj.bin", "GameObject"),
        ("addcomp.bin", "AddComponent"),
        ("source.bin", "source"),
        ("running.bin", "running"),
        ("runscript.bin", "RunScript"),
        ("sysinfo.bin", "SystemInfo"),
        ("devuid.bin", "get_deviceUniqueIdentifier"),
        ("getdevuid.bin", "GetDeviceUniqueIdentifier"),
    ];

    for (fname, val) in items {
        let path = out_dir.join(fname);
        let data = xor_bytes(val, key);
        fs::write(path, data).unwrap();
    }
}
