mod il2cpp;

use il2cpp::Il2Cpp;
use once_cell::sync::Lazy;
use serde::Deserialize;
use base64::Engine;
use rand::{distributions::Alphanumeric, Rng};
use std::ffi::{c_void, CString};
use std::fs::OpenOptions;
use std::io::Write;
use std::sync::atomic::{AtomicBool, AtomicPtr, AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::Duration;
use windows::Win32::Foundation::{BOOL, HMODULE};
use windows::Win32::Storage::FileSystem::{ReadFile, WriteFile, PIPE_ACCESS_DUPLEX};
use windows::Win32::System::Console::AllocConsole;
use windows::Win32::System::LibraryLoader::{DisableThreadLibraryCalls, GetModuleHandleA};
use windows::Win32::System::Diagnostics::Debug::{AddVectoredExceptionHandler, EXCEPTION_POINTERS};
use windows::Win32::System::Memory::{
    VirtualAlloc, VirtualProtect, MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE, PAGE_PROTECTION_FLAGS,
};
use windows::Win32::System::Pipes::{
    ConnectNamedPipe, CreateNamedPipeA, PIPE_READMODE_MESSAGE, PIPE_TYPE_MESSAGE, PIPE_UNLIMITED_INSTANCES, PIPE_WAIT,
};
use windows::Win32::System::SystemServices::{DLL_PROCESS_ATTACH, DLL_PROCESS_DETACH};
use windows::Win32::System::Threading::{CreateThread, THREAD_CREATION_FLAGS};
use windows::Win32::Networking::WinHttp::{
    WinHttpCloseHandle, WinHttpConnect, WinHttpOpen, WinHttpOpenRequest, WinHttpQueryDataAvailable,
    WinHttpReadData, WinHttpReceiveResponse, WinHttpSendRequest, WinHttpSetTimeouts,
    WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_FLAG_SECURE, WINHTTP_OPEN_REQUEST_FLAGS,
};


static SESSION_KEY: Lazy<Mutex<Option<[u8; 32]>>> = Lazy::new(|| Mutex::new(None));
static GLOBAL_IL2CPP: Lazy<Mutex<Option<Il2Cpp>>> = Lazy::new(|| Mutex::new(None));


static IL2CPP_NOLOCK: AtomicPtr<c_void> = AtomicPtr::new(std::ptr::null_mut());
unsafe fn il2cpp_nolock() -> Option<&'static Il2Cpp> {
    let p = IL2CPP_NOLOCK.load(Ordering::Relaxed);
    if p.is_null() { None } else { Some(&*(p as *const Il2Cpp)) }
}


static NATIVELOG_INSTALLED: AtomicBool = AtomicBool::new(false);
static ASSIGNLOCAL_TARGET: AtomicPtr<u8> = AtomicPtr::new(std::ptr::null_mut());
static ASSIGNLOCAL_ORIG_BYTE: AtomicPtr<u8> = AtomicPtr::new(std::ptr::null_mut());
static ASSIGNLOCAL_STEPPING: AtomicBool = AtomicBool::new(false);
static ASSIGNLOCAL_HITS: AtomicU64 = AtomicU64::new(0);
static VEH_READY: AtomicBool = AtomicBool::new(false);

static SYMREF_GETNAME_MI: AtomicPtr<c_void> = AtomicPtr::new(std::ptr::null_mut());
static DV_CASTTOSTRING_MI: AtomicPtr<c_void> = AtomicPtr::new(std::ptr::null_mut());

static DEVICE_ID_HOOKED: AtomicBool = AtomicBool::new(false);
static DEVICE_ID_VALUE: Lazy<String> = Lazy::new(|| {
    rand::thread_rng()
        .sample_iter(&Alphanumeric)
        .take(32)
        .map(char::from)
        .collect()
});

const EXC_BREAKPOINT: u32 = 0x80000003;
const EXC_SINGLE_STEP: u32 = 0x80000004;

unsafe extern "system" fn veh_handler(exc: *mut EXCEPTION_POINTERS) -> i32 {
    if exc.is_null() { return 0; }
    let ep = &*exc;
    if ep.ExceptionRecord.is_null() || ep.ContextRecord.is_null() { return 0; }
    let er = &*ep.ExceptionRecord;
    let ctx = &mut *ep.ContextRecord;

    let target = ASSIGNLOCAL_TARGET.load(Ordering::Relaxed);
    if target.is_null() { return 0; }

    if (er.ExceptionCode.0 as u32) == EXC_BREAKPOINT && (er.ExceptionAddress as *mut u8) == target {
        let hit = ASSIGNLOCAL_HITS.fetch_add(1, Ordering::Relaxed) + 1;

        
        let symref = ctx.Rdx as *mut c_void;
        let dv = ctx.R8 as *mut c_void;

        if let Some(il2cpp) = unsafe { il2cpp_nolock() } {
            let get_name = SYMREF_GETNAME_MI.load(Ordering::Relaxed);
            let cast_str = DV_CASTTOSTRING_MI.load(Ordering::Relaxed);
            if !get_name.is_null() && !cast_str.is_null() && !symref.is_null() && !dv.is_null() {
                let (nm_obj, nm_exc) = il2cpp.runtime_invoke_with_exc(get_name, symref, std::ptr::null_mut());
                let (s_obj, s_exc) = il2cpp.runtime_invoke_with_exc(cast_str, dv, std::ptr::null_mut());
                if nm_exc.is_null() && s_exc.is_null() && !nm_obj.is_null() && !s_obj.is_null() {
                    let var = il2cpp.string_to_rust(nm_obj);
                    let val = il2cpp.string_to_rust(s_obj);

                    
                    if let Some(rest) = val.strip_prefix("ARAC~") {
                        let mut it = rest.split('~');
                        let cmd = it.next().unwrap_or("");
                        match cmd {
                            "LOG" => {
                                let msg_b64 = it.next().unwrap_or("");
                                if let Ok(bytes) = decode_b64(msg_b64) {
                                    let msg = String::from_utf8_lossy(&bytes).to_string();
                                    log_line(&format!("[native] local '{}' set -> {}", var, val));
                                    log_line(&format!("the lua env called a native func and said: {}", msg));
                                }
                            }
                            "HTTPGET" => {
                                let url_b64 = it.next().unwrap_or("");
                                let value_b64 = it.next().unwrap_or("");
                                if let (Ok(url), Ok(vn)) = (b64_to_string(url_b64), b64_to_string(value_b64)) {
                                    spawn_httpget_worker(url, vn);
                                }
                            }
                            "HTTPPOST" => {
                                let url_b64 = it.next().unwrap_or("");
                                let body_b64 = it.next().unwrap_or("");
                                let ua_b64 = it.next().unwrap_or("");
                                let timeout_ms = it.next().unwrap_or("0").parse().unwrap_or(0);
                                let value_b64 = it.next().unwrap_or("");
                                if let (Ok(url), Ok(body), Ok(ua), Ok(vn)) = (
                                    b64_to_string(url_b64),
                                    b64_to_string(body_b64),
                                    b64_to_string(ua_b64),
                                    b64_to_string(value_b64),
                                ) {
                                    spawn_httppost_worker(url, body, ua, timeout_ms, vn);
                                }
                            }
                            "WRITEFILE" => {
                                let p = it.next().unwrap_or("");
                                let c = it.next().unwrap_or("");
                                if !p.is_empty() && !c.is_empty() {
                                    spawn_writefile_worker(p.to_string(), c.to_string());
                                }
                            }
                            "READFILE" => {
                                let p = it.next().unwrap_or("");
                                let v = it.next().unwrap_or("");
                                if !p.is_empty() && !v.is_empty() {
                                    if let Ok(vn) = b64_to_string(v) {
                                        spawn_readfile_worker(p.to_string(), vn);
                                    }
                                }
                            }
                            "MAKEFOLDER" => {
                                let p = it.next().unwrap_or("");
                                if !p.is_empty() {
                                    spawn_makefolder_worker(p.to_string());
                                }
                            }
                            "GETFILES" => {
                                let p = it.next().unwrap_or("");
                                let v = it.next().unwrap_or("");
                                if !p.is_empty() && !v.is_empty() {
                                    if let Ok(vn) = b64_to_string(v) {
                                        spawn_getfiles_worker(p.to_string(), vn);
                                    }
                                }
                            }
                            "DELFILE" => {
                                let p = it.next().unwrap_or("");
                                if !p.is_empty() {
                                    spawn_delfile_worker(p.to_string());
                                }
                            }
                            "DELFOLDER" => {
                                let p = it.next().unwrap_or("");
                                if !p.is_empty() {
                                    spawn_delfolder_worker(p.to_string());
                                }
                            }
                            "LOADSTRING" => {
                                let code_b64 = it.next().unwrap_or("");
                                if let Ok(code) = b64_to_string(code_b64) {
                                    spawn_loadstring_worker(code);
                                }
                            }
                            _ => {}
                        }
                    } else if hit <= 5 {
                        log_line(&format!("[*] AssignLocal hit #{} var='{}'", hit, var));
                    }
                }
            }
        }

        // continue original: restore first byte, single-step, reapply INT3
        let orig = ASSIGNLOCAL_ORIG_BYTE.load(Ordering::Relaxed);
        if !orig.is_null() {
            let mut old: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
            let _ = VirtualProtect(target as *const _, 1, PAGE_EXECUTE_READWRITE, &mut old);
            *target = *orig;
            let mut _tmp: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
            let _ = VirtualProtect(target as *const _, 1, old, &mut _tmp);
        }
        ASSIGNLOCAL_STEPPING.store(true, Ordering::Relaxed);
        ctx.EFlags |= 0x100;
        return 0xFFFFFFFFu32 as i32;
    }

    if (er.ExceptionCode.0 as u32) == EXC_SINGLE_STEP && ASSIGNLOCAL_STEPPING.load(Ordering::Relaxed) {
        ASSIGNLOCAL_STEPPING.store(false, Ordering::Relaxed);
        let orig = ASSIGNLOCAL_ORIG_BYTE.load(Ordering::Relaxed);
        if !orig.is_null() {
            let mut old: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
            let _ = VirtualProtect(target as *const _, 1, PAGE_EXECUTE_READWRITE, &mut old);
            *target = 0xCC;
            let mut _tmp: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
            let _ = VirtualProtect(target as *const _, 1, old, &mut _tmp);
        }
        ctx.EFlags &= !0x100;
        return 0xFFFFFFFFu32 as i32;
    }

    0
}

fn wide(s: &str) -> Vec<u16> {
    use std::os::windows::prelude::OsStrExt;
    std::ffi::OsStr::new(s).encode_wide().chain(std::iter::once(0)).collect()
}

fn parse_url(url: &str) -> Option<(bool, String, u16, String)> {
    // Returns (secure, host, port, path_with_query)
    let url = url.trim();
    let (secure, rest) = if let Some(r) = url.strip_prefix("https://") {
        (true, r)
    } else if let Some(r) = url.strip_prefix("http://") {
        (false, r)
    } else {
        return None;
    };

    let (host_port, path) = match rest.find('/') {
        Some(i) => (&rest[..i], &rest[i..]),
        None => (rest, "/"),
    };

    let (host, port) = match host_port.rfind(':') {
        Some(i) if host_port[i + 1..].chars().all(|c| c.is_ascii_digit()) => {
            let host = &host_port[..i];
            let port: u16 = host_port[i + 1..].parse().ok()?;
            (host.to_string(), port)
        }
        _ => (host_port.to_string(), if secure { 443 } else { 80 }),
    };

    Some((secure, host, port, path.to_string()))
}

fn lua_escape(s: &str) -> String {
    // Escape for double-quoted Lua string literal.
    let mut out = String::with_capacity(s.len() + 16);
    for ch in s.chars() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\r' => {}
            '\n' => out.push_str("\\n"),
            _ => out.push(ch),
        }
    }
    out
}

unsafe fn winhttp_get(url: &str) -> Result<String, String> {
    winhttp_request("GET", url, None, 0)
}

fn spawn_httpget_worker(url: String, value_name: String) {
    std::thread::spawn(move || unsafe {
        let Some(il2cpp) = il2cpp_nolock() else {
            return;
        };
        il2cpp.attach();

        let resp = match winhttp_get(&url) {
            Ok(s) => s,
            Err(e) => format!("HTTPGET ERROR: {e}"),
        };

        let escaped = lua_escape(&resp);
        let script = format!(
            r#"
do
  local pg = game["PlayerGUI"]
  local folder = pg:FindChild("ClientValues")
  if not folder then
    folder = Instance.New("Folder", pg)
    folder.Name = "ClientValues"
  end
  local v = folder:FindChild("{name}")
  if not v then
    v = Instance.New("StringValue", folder)
    v.Name = "{name}"
  end
  v.Value = "{val}"
end
"#,
            name = value_name,
            val = escaped
        );

        // Reuse existing execution path by calling ScriptService.RunScript flow via execute_script.
        let funcs = GameFunctions { il2cpp: il2cpp.clone() };
        let _ = execute_script(&funcs, &script);
    });
}

fn spawn_loadstring_worker(code: String) {
    std::thread::spawn(move || unsafe {
        let Some(il2cpp) = il2cpp_nolock() else { return; };
        il2cpp.attach();
        let funcs = GameFunctions { il2cpp: il2cpp.clone() };
        let _ = execute_script(&funcs, &code);
    });
}

fn base_dir() -> std::path::PathBuf {
    // Sandbox root: prefer a writable per-user directory.
    // current_dir() inside the game is often under Program Files and not writable.
    if let Ok(p) = std::env::var("LOCALAPPDATA") {
        return std::path::PathBuf::from(p).join("AracFiles");
    }
    std::env::temp_dir().join("AracFiles")
}

fn safe_relpath(rel: &str) -> Result<std::path::PathBuf, String> {
    let mut out = std::path::PathBuf::new();
    let s = rel.replace('\\', "/");
    for part in s.split('/') {
        if part.is_empty() || part == "." {
            continue;
        }
        if part == ".." {
            return Err("path traversal not allowed".to_string());
        }
        if part.contains(':') {
            return Err("invalid path".to_string());
        }
        out.push(part);
    }
    Ok(out)
}

fn decode_b64(s: &str) -> Result<Vec<u8>, String> {
    base64::engine::general_purpose::STANDARD
        .decode(s.as_bytes())
        .map_err(|_| "base64 decode failed".to_string())
}

fn b64_to_string(s: &str) -> Result<String, String> {
    decode_b64(s).and_then(|v| String::from_utf8(v).map_err(|_| "utf-8 decode failed".to_string()))
}

fn respond_value(value_name: &str, text: &str) {
    // Create/update StringValue by executing a Lua snippet immediately.
    // This matches the HttpGet flow which is known to work in this environment.
    let escaped = lua_escape(text);
    let script = format!(
        r#"
do
  local pg = game["PlayerGUI"]
  local folder = pg:FindChild("ClientValues")
  if not folder then
    folder = Instance.New("Folder", pg)
    folder.Name = "ClientValues"
  end
  local v = folder:FindChild("{name}")
  if not v then
    v = Instance.New("StringValue", folder)
    v.Name = "{name}"
  end
  v.Value = "{val}"
end
"#,
        name = value_name,
        val = escaped
    );

    unsafe {
        let Some(il2cpp) = il2cpp_nolock() else {
            return;
        };
        il2cpp.attach();
        let funcs = GameFunctions { il2cpp: il2cpp.clone() };
        if let Err(e) = execute_script(&funcs, &script) {
            log_line(&format!("[-] respond_value: execute_script failed: {e}"));
        }
    }
}

fn spawn_writefile_worker(path_b64: String, content_b64: String) {
    std::thread::spawn(move || {
        let base = base_dir();
        if let Err(e) = std::fs::create_dir_all(&base) {
            log_line(&format!("[-] writefile: failed to create base dir {:?}: {}", base, e));
            return;
        }

        let rel = match decode_b64(&path_b64).and_then(|v| String::from_utf8(v).map_err(|_| "path not utf-8".to_string())) {
            Ok(s) => s,
            Err(e) => { log_line(&format!("[-] writefile: {e}")); return; }
        };
        let content = match decode_b64(&content_b64) {
            Ok(v) => v,
            Err(e) => { log_line(&format!("[-] writefile: {e}")); return; }
        };

        let relp = match safe_relpath(&rel) {
            Ok(p) => p,
            Err(e) => { log_line(&format!("[-] writefile: {e}")); return; }
        };
        let full = base.join(relp);
        if let Some(parent) = full.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        if let Err(e) = std::fs::write(&full, content) {
            log_line(&format!("[-] writefile: failed to write {:?}: {}", full, e));
        }
    });
}

fn spawn_readfile_worker(path_b64: String, value_name: String) {
    std::thread::spawn(move || {
        let base = base_dir();
        let _ = std::fs::create_dir_all(&base);

        let rel = match decode_b64(&path_b64).and_then(|v| String::from_utf8(v).map_err(|_| "path not utf-8".to_string())) {
            Ok(s) => s,
            Err(e) => { respond_value(&value_name, &format!("READFILE ERROR: {e}")); return; }
        };
        let relp = match safe_relpath(&rel) {
            Ok(p) => p,
            Err(e) => { respond_value(&value_name, &format!("READFILE ERROR: {e}")); return; }
        };
        let full = base.join(relp);
        log_line(&format!("[*] readfile: vn='{}' rel='{}' full='{}'", value_name, rel, full.display()));
        match std::fs::read(&full) {
            Ok(bytes) => {
                let s = String::from_utf8_lossy(&bytes).to_string();
                // Avoid re-entrancy: responding "too fast" can happen while the VM is still executing the caller script.
                std::thread::sleep(Duration::from_millis(250));
                respond_value(&value_name, &s);
            }
            Err(e) => {
                std::thread::sleep(Duration::from_millis(250));
                respond_value(&value_name, &format!("READFILE ERROR: {}", e))
            }
        }
    });
}

fn spawn_makefolder_worker(path_b64: String) {
    std::thread::spawn(move || {
        let base = base_dir();
        let _ = std::fs::create_dir_all(&base);
        let rel = match decode_b64(&path_b64).and_then(|v| String::from_utf8(v).map_err(|_| "path not utf-8".to_string())) {
            Ok(s) => s,
            Err(_) => return,
        };
        let relp = match safe_relpath(&rel) {
            Ok(p) => p,
            Err(_) => return,
        };
        let full = base.join(relp);
        let _ = std::fs::create_dir_all(full);
    });
}

fn spawn_getfiles_worker(path_b64: String, value_name: String) {
    std::thread::spawn(move || {
        let base = base_dir();
        let _ = std::fs::create_dir_all(&base);
        let rel = match decode_b64(&path_b64).and_then(|v| String::from_utf8(v).map_err(|_| "path not utf-8".to_string())) {
            Ok(s) => s,
            Err(e) => { respond_value(&value_name, &format!("GETFILES ERROR: {e}")); return; }
        };
        let relp = match safe_relpath(&rel) {
            Ok(p) => p,
            Err(e) => { respond_value(&value_name, &format!("GETFILES ERROR: {e}")); return; }
        };
        let full = base.join(relp);
        log_line(&format!("[*] getfiles: vn='{}' rel='{}' full='{}'", value_name, rel, full.display()));
        let mut parts: Vec<String> = Vec::new();
        if let Ok(rd) = std::fs::read_dir(full) {
            for entry in rd.flatten() {
                if let Ok(ft) = entry.file_type() {
                    let name = entry.file_name().to_string_lossy().to_string();
                    if ft.is_dir() {
                        parts.push(format!("{{folder:: {}}}", name));
                    } else {
                        parts.push(format!("{{file:: {}}}", name));
                    }
                }
            }
        }
        std::thread::sleep(Duration::from_millis(250));
        respond_value(&value_name, &parts.join(" "));
    });
}

fn spawn_delfile_worker(path_b64: String) {
    std::thread::spawn(move || {
        let base = base_dir();
        let _ = std::fs::create_dir_all(&base);
        let rel = match decode_b64(&path_b64)
            .and_then(|v| String::from_utf8(v).map_err(|_| "path not utf-8".to_string()))
        {
            Ok(s) => s,
            Err(_) => return,
        };
        let relp = match safe_relpath(&rel) {
            Ok(p) => p,
            Err(_) => return,
        };
        let full = base.join(relp);
        let _ = std::fs::remove_file(full);
    });
}

fn spawn_delfolder_worker(path_b64: String) {
    std::thread::spawn(move || {
        let base = base_dir();
        let _ = std::fs::create_dir_all(&base);
        let rel = match decode_b64(&path_b64)
            .and_then(|v| String::from_utf8(v).map_err(|_| "path not utf-8".to_string()))
        {
            Ok(s) => s,
            Err(_) => return,
        };
        let relp = match safe_relpath(&rel) {
            Ok(p) => p,
            Err(_) => return,
        };
        let full = base.join(relp);
        let _ = std::fs::remove_dir_all(full);
    });
}

fn spawn_httppost_worker(url: String, body: String, _ua: String, timeout_ms: u32, value_name: String) {
    std::thread::spawn(move || unsafe {
        let Some(il2cpp) = il2cpp_nolock() else { return; };
        il2cpp.attach();
        let resp = match winhttp_request("POST", &url, Some(body.as_bytes()), timeout_ms) {
            Ok(s) => s,
            Err(e) => format!("HTTPPOST ERROR: {e}"),
        };
        respond_value(&value_name, &resp);
    });
}

unsafe fn winhttp_request(method: &str, url: &str, body: Option<&[u8]>, timeout_ms: u32) -> Result<String, String> {
    let Some((secure, host, port, path)) = parse_url(url) else {
        return Err("unsupported url (only http/https)".to_string());
    };

    let h_session = WinHttpOpen(
        windows::core::w!("polytoria_interface/NativeHTTP"),
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        windows::core::PCWSTR::null(),
        windows::core::PCWSTR::null(),
        0,
    );
    if h_session.is_null() {
        return Err("WinHttpOpen failed".to_string());
    }
    if timeout_ms > 0 {
        let _ = WinHttpSetTimeouts(h_session, timeout_ms as i32, timeout_ms as i32, timeout_ms as i32, timeout_ms as i32);
    }

    let h_connect = WinHttpConnect(h_session, windows::core::PCWSTR(wide(&host).as_ptr()), port, 0);
    if h_connect.is_null() {
        let _ = WinHttpCloseHandle(h_session);
        return Err("WinHttpConnect failed".to_string());
    }

    let flags = if secure { WINHTTP_FLAG_SECURE } else { WINHTTP_OPEN_REQUEST_FLAGS(0) };
    let verb = wide(method);
    let h_request = WinHttpOpenRequest(
        h_connect,
        windows::core::PCWSTR(verb.as_ptr()),
        windows::core::PCWSTR(wide(&path).as_ptr()),
        windows::core::PCWSTR::null(),
        windows::core::PCWSTR::null(),
        std::ptr::null(),
        flags,
    );
    if h_request.is_null() {
        let _ = WinHttpCloseHandle(h_connect);
        let _ = WinHttpCloseHandle(h_session);
        return Err("WinHttpOpenRequest failed".to_string());
    }

    let (opt_ptr, opt_len) = match body {
        Some(b) if !b.is_empty() => (Some(b.as_ptr() as *const c_void), b.len() as u32),
        _ => (None, 0u32),
    };

    if WinHttpSendRequest(h_request, None, opt_ptr, opt_len, opt_len, 0).is_err() {
        let _ = WinHttpCloseHandle(h_request);
        let _ = WinHttpCloseHandle(h_connect);
        let _ = WinHttpCloseHandle(h_session);
        return Err("WinHttpSendRequest failed".to_string());
    }

    if WinHttpReceiveResponse(h_request, std::ptr::null_mut()).is_err() {
        let _ = WinHttpCloseHandle(h_request);
        let _ = WinHttpCloseHandle(h_connect);
        let _ = WinHttpCloseHandle(h_session);
        return Err("WinHttpReceiveResponse failed".to_string());
    }

    let mut buf = Vec::<u8>::new();
    loop {
        let mut avail: u32 = 0;
        if WinHttpQueryDataAvailable(h_request, &mut avail).is_err() {
            break;
        }
        if avail == 0 {
            break;
        }
        let start = buf.len();
        buf.resize(start + avail as usize, 0u8);
        let mut read: u32 = 0;
        if WinHttpReadData(h_request, buf[start..].as_mut_ptr() as *mut _, avail, &mut read).is_err() {
            break;
        }
        buf.truncate(start + read as usize);
    }

    let _ = WinHttpCloseHandle(h_request);
    let _ = WinHttpCloseHandle(h_connect);
    let _ = WinHttpCloseHandle(h_session);

    String::from_utf8(buf).map_err(|_| "response not utf-8".to_string())
}

unsafe fn install_int3(target: *mut u8) -> bool {
    if target.is_null() { return false; }
    let orig_store = VirtualAlloc(None, 1, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE) as *mut u8;
    if orig_store.is_null() { return false; }
    *orig_store = *target;
    ASSIGNLOCAL_ORIG_BYTE.store(orig_store, Ordering::Relaxed);
    ASSIGNLOCAL_TARGET.store(target, Ordering::Relaxed);

    if !VEH_READY.swap(true, Ordering::Relaxed) {
        let h = AddVectoredExceptionHandler(1, Some(veh_handler));
        if h.is_null() { return false; }
    }

    let mut old: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
    if VirtualProtect(target as *const _, 1, PAGE_EXECUTE_READWRITE, &mut old).is_err() { return false; }
    *target = 0xCC;
    let mut _tmp: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
    let _ = VirtualProtect(target as *const _, 1, old, &mut _tmp);
    true
}

unsafe fn patch_jump(target: *mut u8, detour: *const u8) -> bool {
    if target.is_null() || detour.is_null() {
        return false;
    }

    let mut old: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
    if VirtualProtect(target as *const _, 16, PAGE_EXECUTE_READWRITE, &mut old).is_err() {
        return false;
    }

    let mut buf = [0x90u8; 16];
    buf[0] = 0x48;
    buf[1] = 0xB8;
    let addr = detour as u64;
    buf[2..10].copy_from_slice(&addr.to_le_bytes());
    buf[10] = 0xFF;
    buf[11] = 0xE0;

    std::ptr::copy_nonoverlapping(buf.as_ptr(), target, buf.len());

    let mut _tmp: PAGE_PROTECTION_FLAGS = PAGE_PROTECTION_FLAGS(0);
    let _ = VirtualProtect(target as *const _, 16, old, &mut _tmp);
    true
}

unsafe fn ensure_native_log_hook(il2cpp: &Il2Cpp) {
    if NATIVELOG_INSTALLED.load(Ordering::Relaxed) {
        return;
    }

    let Some(asm_fp) = il2cpp.get_image("Assembly-CSharp-firstpass").or_else(|| il2cpp.get_image("Assembly-CSharp")) else {
        return;
    };
    let Some(proc_class) = il2cpp.get_class(asm_fp, "MoonSharp.Interpreter.Execution.VM", "Processor") else {
        return;
    };
    let Some(mi) = il2cpp.class_get_method_from_name(proc_class, "AssignLocal", 2) else {
        return;
    };

    if SYMREF_GETNAME_MI.load(Ordering::Relaxed).is_null() {
        if let Some(symref_class) = il2cpp.get_class(asm_fp, "MoonSharp.Interpreter", "SymbolRef") {
            if let Some(m) = il2cpp.class_get_method_from_name(symref_class, "get_Name", 0) {
                SYMREF_GETNAME_MI.store(m, Ordering::Relaxed);
            }
        }
    }
    if DV_CASTTOSTRING_MI.load(Ordering::Relaxed).is_null() {
        if let Some(dv_class) = il2cpp.get_class(asm_fp, "MoonSharp.Interpreter", "DynValue") {
            if let Some(m) = il2cpp.class_get_method_from_name(dv_class, "CastToString", 0) {
                DV_CASTTOSTRING_MI.store(m, Ordering::Relaxed);
            }
        }
    }

    let target_ptr = il2cpp
        .method_get_pointer(mi)
        .map(|p| p as *mut u8)
        .unwrap_or_else(|| unsafe { *(mi as *mut *mut u8) });
    if target_ptr.is_null() {
        return;
    }
    if install_int3(target_ptr) {
        NATIVELOG_INSTALLED.store(true, Ordering::Relaxed);
        log_line("[+] NativeLog hook installed (Processor.AssignLocal)");
    }
}


fn deobf(bytes: &[u8]) -> String {
    const KEY: u8 = 0xA7;
    let mut out = Vec::with_capacity(bytes.len());
    for &b in bytes {
        out.push(b ^ KEY);
    }
   
    unsafe { String::from_utf8_unchecked(out) }
}

macro_rules! obf {
    ($name:literal) => {{
        deobf(include_bytes!(concat!(env!("OUT_DIR"), "/", $name)))
    }};
}

unsafe extern "C" fn fake_device_unique_identifier() -> *mut c_void {
    let Some(il2cpp) = il2cpp_nolock() else {
        return std::ptr::null_mut();
    };
    il2cpp.attach();
    il2cpp.string_new(&DEVICE_ID_VALUE)
}

unsafe fn ensure_device_id_hook(il2cpp: &Il2Cpp) {
    if DEVICE_ID_HOOKED.load(Ordering::Relaxed) {
        return;
    }

    let ucore = obf!("ucore.bin");
    let unity_ns = obf!("unityns.bin");
    let sysinfo = obf!("sysinfo.bin");
    let getter = obf!("devuid.bin");
    let alt_getter = obf!("getdevuid.bin");

    let Some(img) = il2cpp.get_image(&ucore) else { return; };
    let Some(class_sysinfo) = il2cpp.get_class(img, &unity_ns, &sysinfo) else { return; };

    let mut hooked = false;
    for name in [&getter, &alt_getter] {
        if let Some(mi) = il2cpp.class_get_method_from_name(class_sysinfo, name, 0) {
            let ptr = il2cpp
                .method_get_pointer(mi)
                .map(|p| p as *mut u8)
                .unwrap_or_else(|| unsafe { *(mi as *mut *mut u8) });
            if !ptr.is_null() && patch_jump(ptr, fake_device_unique_identifier as *const u8) {
                hooked = true;
            }
        }
    }

    if hooked {
        DEVICE_ID_HOOKED.store(true, Ordering::Relaxed);
        log_line(&format!(
            "[+] SystemInfo.deviceUniqueIdentifier hooked -> {}",
            &*DEVICE_ID_VALUE
        ));
    } else {
        log_line("[-] Failed to hook SystemInfo.deviceUniqueIdentifier");
    }
}

// Keep this defensive: if the engine disables io/os libs, the helpers error clearly.
const LUA_PRELUDE: &str = r#"
-- polytoria_interface prelude (executor helpers)
do
  local function _tassert(cond, msg)
    if not cond then error(msg, 3) end
  end

  -- Basic yield-based wait (Polytoria defines wait() via ScriptService.payload, but keep a fallback)
  if type(wait) ~= "function" then
    function wait(n)
      if coroutine and coroutine.yield then
        return coroutine.yield(n or 0)
      end
    end
  end

  -- loadstring compatibility (Lua 5.1 vs 5.2+). MoonSharp may expose either.
  if type(loadstring) ~= "function" and type(load) == "function" then
    loadstring = load
  end

  -- Minimal game:HttpGet shim using the game's HttpService (async callback -> sync via yielding)
  local function _http_get(url)
    _tassert(type(url) == "string", "HttpGet: url must be a string")

    local hs = rawget(_G, "HttpService") or rawget(_G, "httpservice")
    local get = hs and (hs.Get or hs.get)
    _tassert(type(get) == "function", "HttpGet: HttpService.Get not available in this environment")

    local done, result = false, nil
    local cb = function(res)
      result = res
      done = true
    end

    -- HttpService.Get(url, callback, headers?)
    get(url, cb)

    while not done do
      wait(0.05)
    end
    return result
  end

  if type(game) == "table" and type(game.HttpGet) ~= "function" then
    function game:HttpGet(url)
      return _http_get(url)
    end
  end

  -- Filesystem sandbox: only allow relative paths under "files/".
  local function _sandbox_rel(p)
    _tassert(type(p) == "string", "path must be a string")
    p = p:gsub("\\\\", "/")
    _tassert(not p:match("^%a:/"), "absolute paths not allowed")
    _tassert(not p:match("^/"), "absolute paths not allowed")
    _tassert(not p:match("^%./"), "paths starting with ./ not allowed")
    _tassert(not p:find("..", 1, true), "path traversal not allowed")
    _tassert(not p:find(":", 1, true), "drive spec not allowed")
    return "files/" .. p
  end

  local function _need_io()
    _tassert(type(io) == "table" and type(io.open) == "function", "io library not available")
  end

  -- writefile/readfile
  if type(writefile) ~= "function" then
    function writefile(path, data)
      _need_io()
      local p = _sandbox_rel(path)
      _tassert(type(data) == "string", "writefile: data must be a string")
      local f = assert(io.open(p, "wb"))
      f:write(data)
      f:close()
      return true
    end
  end

  if type(readfile) ~= "function" then
    function readfile(path)
      _need_io()
      local p = _sandbox_rel(path)
      local f = assert(io.open(p, "rb"))
      local d = f:read("*a")
      f:close()
      return d
    end
  end

  -- createfolder/delfile/delfolder/getfolderfiles: best-effort depending on os/lfs availability.
  local function _need_os()
    _tassert(type(os) == "table", "os library not available")
  end

  if type(createfolder) ~= "function" then
    function createfolder(path)
      local p = _sandbox_rel(path)
      if type(lfs) == "table" and type(lfs.mkdir) == "function" then
        return lfs.mkdir(p)
      end
      _need_os()
      -- Windows: mkdir handles nested paths; on other platforms this may vary.
      return os.execute('mkdir "' .. p .. '"') == 0
    end
  end

  if type(delfile) ~= "function" then
    function delfile(path)
      local p = _sandbox_rel(path)
      if type(os) == "table" and type(os.remove) == "function" then
        return os.remove(p)
      end
      error("delfile: os.remove not available", 2)
    end
  end

  if type(delfolder) ~= "function" then
    function delfolder(path)
      local p = _sandbox_rel(path)
      if type(lfs) == "table" and type(lfs.rmdir) == "function" then
        return lfs.rmdir(p)
      end
      _need_os()
      return os.execute('rmdir /s /q "' .. p .. '"') == 0
    end
  end

  if type(getfolderfiles) ~= "function" then
    function getfolderfiles(path)
      local p = _sandbox_rel(path)
      local out = {}
      if type(lfs) == "table" and type(lfs.dir) == "function" then
        for name in lfs.dir(p) do
          if name ~= "." and name ~= ".." then
            out[#out + 1] = name
          end
        end
        return out
      end
      error("getfolderfiles: lfs not available", 2)
    end
  end
end
"#;

// Extra Lua helpers shipped alongside the DLL (e.g. HttpGet bridge).
const LUA_FUNCS: &str = include_str!("../luafuncs.lua");

struct GameFunctions {
    pub il2cpp: Il2Cpp,
}

impl GameFunctions {
    unsafe fn new() -> Option<Self> {
        let ga = obf!("ga.bin");
        let game_assembly = GetModuleHandleA(windows::core::PCSTR(ga.as_ptr())).ok()?;
        let il2cpp = Il2Cpp::new(game_assembly)?;
        *GLOBAL_IL2CPP.lock().unwrap() = Some(il2cpp.clone());
        if IL2CPP_NOLOCK.load(Ordering::Relaxed).is_null() {
            let boxed = Box::new(il2cpp.clone());
            IL2CPP_NOLOCK.store(Box::into_raw(boxed) as *mut c_void, Ordering::Relaxed);
        }
        Some(Self { il2cpp })
    }
}

#[no_mangle]
#[allow(non_snake_case)]
unsafe extern "system" fn DllMain(_: HMODULE, call_reason: u32, _: *mut c_void) -> BOOL {
    if call_reason == DLL_PROCESS_ATTACH {
        
        let self_name = obf!("self.bin");
        if let Ok(h) = GetModuleHandleA(windows::core::PCSTR(self_name.as_ptr())) {
            let _ = DisableThreadLibraryCalls(h);
        }
        let _ = CreateThread(
            None,
            0,
            Some(main_thread_trampoline),
            None,
            THREAD_CREATION_FLAGS(0),
            None,
        );
    } else if call_reason == DLL_PROCESS_DETACH {
        
    }
    BOOL::from(true)
}

unsafe extern "system" fn main_thread_trampoline(_: *mut c_void) -> u32 {
    let _ = std::panic::catch_unwind(|| unsafe { main_thread() });
    0
}

unsafe fn main_thread() {
    let _ = AllocConsole();
    log_line("[+] Polytoria Executor DLL Injected (Rust - Dynamic)");

    
    let funcs = loop {
        if let Some(f) = GameFunctions::new() {
            break f;
        }
        std::thread::sleep(Duration::from_millis(250));
    };

    log_line("[+] Il2Cpp Initialized");
    log_line("[*] Attaching to Il2Cpp thread...");
    funcs.il2cpp.attach();
    log_line("[+] Attached!");
    ensure_device_id_hook(&funcs.il2cpp);

    let pipe_name = CString::new(obf!("pipe.bin")).unwrap();
    log_line(&format!("[*] Pipe server: {}", pipe_name.to_string_lossy()));

    loop {
        log_line("[*] Waiting for client connection...");

        let pipe = CreateNamedPipeA(
            windows::core::PCSTR(pipe_name.as_ptr() as *const u8),
            PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
            PIPE_UNLIMITED_INSTANCES,
            // Pipe buffers are per-call hints; payloads can be larger, but bigger buffers reduce
            // fragmentation and ERROR_MORE_DATA reads for large scripts.
            1024 * 256,
            1024 * 256,
            0,
            None,
        )
        .unwrap();

        if pipe.is_invalid() {
            log_line("[-] Failed to create pipe");
            std::thread::sleep(Duration::from_secs(1));
            continue;
        }

        let connected = ConnectNamedPipe(pipe, None);
        let is_connected = match connected {
            Ok(_) => true,
            Err(ref e) => {
                windows::Win32::Foundation::WIN32_ERROR::from_error(e)
                    == Some(windows::Win32::Foundation::ERROR_PIPE_CONNECTED)
            }
        };

        if is_connected {
            log_line("[+] Client Connected");
            handle_client(pipe, &funcs);
            log_line("[*] Client disconnected");
        }

        let _ = windows::Win32::Foundation::CloseHandle(pipe);
    }
}

unsafe fn handle_client(pipe: windows::Win32::Foundation::HANDLE, funcs: &GameFunctions) {
    // Read the full message from a message-mode named pipe.
    // Large payloads can exceed a single ReadFile() call; in that case ReadFile returns
    // ERROR_MORE_DATA and we must continue reading until the full message is received.
    let msg_bytes = match read_pipe_message(pipe) {
        Ok(b) => b,
        Err(e) => {
            log_line(&format!("[-] ReadFile failed: {}", e));
            let _ = write_pipe_line(pipe, format!("ERR: ReadFile failed: {e}\n").as_bytes());
            return;
        }
    };

    if msg_bytes.is_empty() {
        let _ = write_pipe_line(pipe, b"ERR: empty payload\n");
        return;
    }

    let script_content = String::from_utf8_lossy(&msg_bytes).to_string();
    let msg = script_content.trim_matches(char::from(0)).trim().to_string();

    
    if msg.starts_with('{') {
        match unsafe { handle_json_message(pipe, funcs, &msg) } {
            Ok(()) => return,
            Err(e) => {
                let _ = write_pipe_line(pipe, format!("ERR: {e}\n").as_bytes());
                return;
            }
        }
    }

    log_line(&format!("[+] Received Script ({} chars) [plaintext]", msg.len()));
    match execute_script(funcs, &msg) {
        Ok(()) => {
            log_line("[+] Script executed successfully");
            let _ = write_pipe_line(pipe, b"OK\n");
        }
        Err(msg) => {
            log_line(&format!("[-] Script execution failed: {}", msg));
            let line = format!("ERR: {msg}\n");
            let _ = write_pipe_line(pipe, line.as_bytes());
        }
    }
}

unsafe fn read_pipe_message(
    pipe: windows::Win32::Foundation::HANDLE,
) -> Result<Vec<u8>, windows::core::Error> {
    use windows::Win32::Foundation::{WIN32_ERROR, ERROR_MORE_DATA};

    // 16KiB chunks; grow as needed.
    let mut out: Vec<u8> = Vec::new();
    let mut chunk = [0u8; 16 * 1024];

    loop {
        let mut bytes_read: u32 = 0;
        match ReadFile(pipe, Some(&mut chunk), Some(&mut bytes_read), None) {
            Ok(()) => {
                if bytes_read == 0 {
                    break;
                }
                out.extend_from_slice(&chunk[..bytes_read as usize]);
                break;
            }
            Err(e) => {
                // For message-mode named pipes, ERROR_MORE_DATA means the buffer was too small,
                // but bytes_read contains the number of bytes read so far.
                if WIN32_ERROR::from_error(&e) == Some(ERROR_MORE_DATA) {
                    if bytes_read != 0 {
                        out.extend_from_slice(&chunk[..bytes_read as usize]);
                    }
                    continue;
                }
                return Err(e);
            }
        }
    }

    Ok(out)
}

#[derive(Deserialize)]
struct HelloMsg {
    #[serde(rename = "type")]
    msg_type: String,
    v: Option<u32>,
    #[serde(default)]
    sessionKeyB64: String,
    #[serde(default)]
    sessionId: String,
    #[serde(default)]
    token: String,
}

#[derive(Deserialize)]
struct ExecMsg {
    #[serde(rename = "type")]
    msg_type: String,
    v: Option<u32>,
    #[serde(default)]
    sessionId: String,
    nonceB64: String,
    ctB64: String,
    tagB64: String,
}

unsafe fn handle_json_message(
    pipe: windows::Win32::Foundation::HANDLE,
    funcs: &GameFunctions,
    msg: &str,
) -> Result<(), String> {
    
    let v: serde_json::Value = serde_json::from_str(msg).map_err(|e| format!("bad json: {e}"))?;
    let t = v
        .get("type")
        .and_then(|x| x.as_str())
        .unwrap_or("")
        .to_string();

    if t == "hello" {
        let hm: HelloMsg = serde_json::from_value(v).map_err(|e| format!("bad hello: {e}"))?;
        if hm.v.unwrap_or(0) != 1 {
            return Err("unsupported protocol version".to_string());
        }
        let key_bytes = {
            use base64::engine::general_purpose::STANDARD;
            use base64::Engine;
            STANDARD
                .decode(hm.sessionKeyB64.as_bytes())
                .map_err(|e| format!("bad sessionKeyB64: {e}"))?
        };
        if key_bytes.len() != 32 {
            return Err(format!("session key length invalid (expected 32, got {})", key_bytes.len()));
        }
        let mut k = [0u8; 32];
        k.copy_from_slice(&key_bytes);
        *SESSION_KEY.lock().unwrap() = Some(k);
        log_line("[+] Session key set via hello");
        let _ = write_pipe_line(pipe, b"OK\n");
        return Ok(());
    }

    if t == "exec" {
        let em: ExecMsg = serde_json::from_value(v).map_err(|e| format!("bad exec: {e}"))?;
        if em.v.unwrap_or(0) != 1 {
            return Err("unsupported protocol version".to_string());
        }

        let key = SESSION_KEY
            .lock()
            .unwrap()
            .ok_or_else(|| "no session key set (send hello first)".to_string())?;

        let (nonce, ct, tag) = {
            use base64::engine::general_purpose::STANDARD;
            use base64::Engine;
            let nonce = STANDARD
                .decode(em.nonceB64.as_bytes())
                .map_err(|e| format!("bad nonceB64: {e}"))?;
            let ct = STANDARD
                .decode(em.ctB64.as_bytes())
                .map_err(|e| format!("bad ctB64: {e}"))?;
            let tag = STANDARD
                .decode(em.tagB64.as_bytes())
                .map_err(|e| format!("bad tagB64: {e}"))?;
            (nonce, ct, tag)
        };

        if nonce.len() != 12 {
            return Err(format!("nonce length invalid (expected 12, got {})", nonce.len()));
        }
        if tag.len() != 16 {
            return Err(format!("tag length invalid (expected 16, got {})", tag.len()));
        }

        let script = match decrypt_exec(&key, &em.sessionId, &nonce, &ct, &tag) {
            Ok(s) => s,
            Err(e) => {
                log_line(&format!(
                    "[-] decrypt_exec failed: {} (sessionIdLen={}, nonceLen={}, ctLen={}, tagLen={})",
                    e,
                    em.sessionId.len(),
                    nonce.len(),
                    ct.len(),
                    tag.len()
                ));
                return Err(e);
            }
        };
        log_line(&format!(
            "[+] Received Script ({} chars) [encrypted]",
            script.len()
        ));

        match execute_script(funcs, &script) {
            Ok(()) => {
                let _ = write_pipe_line(pipe, b"OK\n");
                Ok(())
            }
            Err(msg) => {
                let line = format!("ERR: {msg}\n");
                let _ = write_pipe_line(pipe, line.as_bytes());
                Ok(())
            }
        }
    } else {
        Err("unknown message type".to_string())
    }
}

fn decrypt_exec(
    key: &[u8; 32],
    session_id: &str,
    nonce: &[u8],
    ct: &[u8],
    tag: &[u8],
) -> Result<String, String> {
    use aes_gcm::aead::{Aead, KeyInit, Payload};
    use aes_gcm::{Aes256Gcm, Nonce};

    let cipher = Aes256Gcm::new_from_slice(key).map_err(|_| "bad key".to_string())?;
    let nonce = Nonce::from_slice(nonce);

    
    let mut buf = Vec::with_capacity(ct.len() + tag.len());
    buf.extend_from_slice(ct);
    buf.extend_from_slice(tag);

    let aad = session_id.as_bytes();
    let pt = cipher
        .decrypt(nonce, Payload { msg: &buf, aad })
        .map_err(|_| format!("decrypt failed (aadLen={}, bufLen={})", aad.len(), buf.len()))?;

    String::from_utf8(pt).map_err(|_| "decrypted payload is not utf-8".to_string())
}

unsafe fn write_pipe_line(pipe: windows::Win32::Foundation::HANDLE, data: &[u8]) -> bool {
    let mut written: u32 = 0;
    let res = WriteFile(pipe, Some(data), Some(&mut written), None);
    res.is_ok() && (written as usize) == data.len()
}

unsafe fn execute_script(funcs: &GameFunctions, script: &str) -> Result<(), String> {
    let il2cpp = &funcs.il2cpp;
    ensure_native_log_hook(il2cpp);

    
    let mut combined = String::new();
    combined.push_str(LUA_PRELUDE);
    combined.push('\n');
    combined.push_str("\n-- luafuncs.lua (bundled)\n");
    combined.push_str(LUA_FUNCS);
    combined.push('\n');
    combined.push_str(script.trim());
    let script = combined;

    // 1. Get Assembly-CSharp
    let assembly_name = obf!("asmcs.bin");
    let assembly = il2cpp
        .get_image(&assembly_name)
        .ok_or("Failed to get Assembly-CSharp")?;

    // 2. Get Classes
    let ss_name = obf!("ssname.bin");
    let ss_ns = obf!("ssns.bin");
    let script_service_class = il2cpp
        .get_class(assembly, "", &ss_name)
        .or_else(|| il2cpp.get_class(assembly, &ss_ns, &ss_name))
        .ok_or("Failed to get ScriptService class")?;
    let game_name = obf!("gamename.bin");
    let game_ns = obf!("gamens.bin");
    let game_class = il2cpp
        .get_class(assembly, "", &game_name)
        .or_else(|| il2cpp.get_class(assembly, &game_ns, &game_name))
        .ok_or("Failed to get Game class")?;
    let si_name = obf!("siname.bin");
    let script_instance_class = il2cpp
        .get_class(assembly, "", &si_name)
        .or_else(|| il2cpp.get_class(assembly, &game_ns, &si_name))
        .ok_or("Failed to get ScriptInstance class")?;

    // 3. Get Game Instance (singleton)
    let singleton = obf!("singleton.bin");
    let game_instance_field = il2cpp
        .class_get_field_from_name(game_class, &singleton)
        .ok_or("Failed to get Game.singleton field")?;

    let mut game_instance: *mut c_void = std::ptr::null_mut();
    il2cpp.field_static_get_value(
        game_instance_field,
        &mut game_instance as *mut _ as *mut c_void,
    );

    if game_instance.is_null() {
        return Err("Game.singleton is null".to_string());
    }

    // 4. Get ScriptService Instance (<Instance>k__BackingField)
    let backing = obf!("backing.bin");
    let ss_instance_field = il2cpp
        .class_get_field_from_name(script_service_class, &backing)
        .ok_or("Failed to get ScriptService instance field")?;

    let mut script_service_instance: *mut c_void = std::ptr::null_mut();
    il2cpp.field_static_get_value(
        ss_instance_field,
        &mut script_service_instance as *mut _ as *mut c_void,
    );

    if script_service_instance.is_null() {
        return Err("ScriptService instance is null".to_string());
    }

    // 5. Get GameObject from Game Instance
    let ucore = obf!("ucore.bin");
    let unity_core = il2cpp
        .get_image(&ucore)
        .ok_or("Failed to get UnityEngine.CoreModule")?;
    let unity_ns = obf!("unityns.bin");
    let comp_name = obf!("comp.bin");
    let component_class = il2cpp
        .get_class(unity_core, &unity_ns, &comp_name)
        .ok_or("Failed to get Component class")?;

    let get_go = obf!("getgo.bin");
    let get_game_object_method = il2cpp
        .class_get_method_from_name(component_class, &get_go, 0)
        .ok_or("Failed to get Component.get_gameObject")?;

    let game_object = il2cpp.runtime_invoke(
        get_game_object_method,
        game_instance,
        std::ptr::null_mut(),
    );
    if game_object.is_null() {
        return Err("Game.gameObject is null".to_string());
    }

    // 6. AddComponent<ScriptInstance>(pScriptInstance)
    let script_instance_type = il2cpp.class_get_type(script_instance_class);
    if script_instance_type.is_null() {
        return Err("ScriptInstance type is null".to_string());
    }
    let script_instance_system_type = il2cpp.type_get_object(script_instance_type);
    if script_instance_system_type.is_null() {
        return Err("ScriptInstance System.Type is null".to_string());
    }

    let go_name = obf!("gobj.bin");
    let game_object_class = il2cpp
        .get_class(unity_core, &unity_ns, &go_name)
        .ok_or("Failed to get GameObject class")?;
    
    let add_comp = obf!("addcomp.bin");
    let add_component_method = il2cpp
        .class_get_method_from_name(game_object_class, &add_comp, 1)
        .ok_or("Failed to get GameObject.AddComponent")?;

    let mut args = [script_instance_system_type];
    let new_script_instance =
        il2cpp.runtime_invoke(add_component_method, game_object, args.as_mut_ptr());

    if new_script_instance.is_null() {
        return Err("Failed to AddComponent<ScriptInstance>".to_string());
    }

    // 7. Set "source" and "running" fields (Recursive due to il2cpp inheritance quirks)
    let source_str = il2cpp.string_new(&script);

    let mut found_source = false;
    let mut curr_class = script_instance_class;
    while !curr_class.is_null() {
         let source_field = obf!("source.bin");
         if let Some(field) = il2cpp.class_get_field_from_name(curr_class, &source_field) {
             let offset = il2cpp.field_get_offset(field);
             let ptr = (new_script_instance as usize + offset) as *mut *mut c_void;
             *ptr = source_str;
             found_source = true;
            break;
        }
        match il2cpp.class_get_parent(curr_class) {
            Some(parent) => curr_class = parent,
            None => break,
        }
    }
    if !found_source {
        log_line("[-] Warning: could not find 'source' field");
    }

    let mut found_running = false;
    let mut curr_class = script_instance_class;
    while !curr_class.is_null() {
         let running_field = obf!("running.bin");
         if let Some(field) = il2cpp.class_get_field_from_name(curr_class, &running_field) {
             let offset = il2cpp.field_get_offset(field);
             let ptr = (new_script_instance as usize + offset) as *mut bool;
             *ptr = false;
             found_running = true;
            break;
        }
        match il2cpp.class_get_parent(curr_class) {
            Some(parent) => curr_class = parent,
            None => break,
        }
    }
    if !found_running {
        log_line("[-] Warning: could not find 'running' field");
    }

    // 8. RunScript
    let run_script = obf!("runscript.bin");
    let run_script_method = il2cpp
        .class_get_method_from_name(script_service_class, &run_script, 1)
        .or_else(|| il2cpp.class_get_method_from_name(script_service_class, &run_script, 2))
        .ok_or("Failed to get RunScript method")?;

    let mut args = [new_script_instance];
    let (_ret, exc) =
        il2cpp.runtime_invoke_with_exc(run_script_method, script_service_instance, args.as_mut_ptr());
    if !exc.is_null() {
        let detail = format_il2cpp_exception(il2cpp, exc);
        log_line(&format!("[-] RunScript exception: {}", detail));
        return Err(format!("RunScript exception: {detail}"));
    }

    Ok(())
}

unsafe fn format_il2cpp_exception(il2cpp: &Il2Cpp, exc: *mut c_void) -> String {
    if exc.is_null() {
        return "<null>".to_string();
    }

    // Best-effort: call ToString() on the exception object and convert the returned Il2CppString.
    let exc_class = il2cpp.object_get_class(exc);
    if exc_class.is_null() {
        return "<unknown_exception_class>".to_string();
    }

    let to_string = il2cpp.class_get_method_from_name(exc_class, "ToString", 0);
    if let Some(m) = to_string {
        let (ret, inner_exc) = il2cpp.runtime_invoke_with_exc(m, exc, std::ptr::null_mut());
        if inner_exc.is_null() && !ret.is_null() {
            return il2cpp.string_to_rust(ret);
        }
    }

    "<exception (failed to stringify)>".to_string()
}

fn extract_loadstring_literal_chunks(input: &str) -> Result<(Vec<String>, String), String> {
    // Supports only: loadstring("...")() / loadstring('...')() / loadstring([=[...]=])()
    // Removes the call from the script and returns extracted chunks in order.
    let mut chunks: Vec<String> = Vec::new();
    let mut out = String::with_capacity(input.len());
    let bytes = input.as_bytes();
    let mut i = 0usize;

    while i < bytes.len() {
        // Find next "loadstring"
        let rest = &input[i..];
        let Some(pos) = rest.find("loadstring") else {
            out.push_str(rest);
            break;
        };
        // Copy everything before match
        out.push_str(&rest[..pos]);
        i += pos;

        // Ensure it's actually an identifier call (very lightweight check)
        // Allow whitespace then '('
        let mut j = i + "loadstring".len();
        while j < bytes.len() && bytes[j].is_ascii_whitespace() {
            j += 1;
        }
        if j >= bytes.len() || bytes[j] != b'(' {
            // Not a call; keep literal and continue
            out.push_str("loadstring");
            i += "loadstring".len();
            continue;
        }
        j += 1; // after '('
        while j < bytes.len() && bytes[j].is_ascii_whitespace() {
            j += 1;
        }
        if j >= bytes.len() {
            return Err("unexpected EOF after loadstring(".to_string());
        }

        // Parse a literal
        let (lit, j2) = parse_lua_string_literal(input, j)?;
        j = j2;
        while j < bytes.len() && bytes[j].is_ascii_whitespace() {
            j += 1;
        }
        if j >= bytes.len() || bytes[j] != b')' {
            return Err("expected ')' after loadstring(<literal>)".to_string());
        }
        j += 1; // after ')'
        while j < bytes.len() && bytes[j].is_ascii_whitespace() {
            j += 1;
        }

        // Optional immediate call "()" - we only extract if it's there (matches the user's pattern).
        if j + 1 < bytes.len() && bytes[j] == b'(' && bytes[j + 1] == b')' {
            j += 2;
            // Also swallow an optional trailing semicolon/newline whitespace.
            while j < bytes.len() && (bytes[j].is_ascii_whitespace() || bytes[j] == b';') {
                // stop on newline? doesn't matter; we can swallow spaces/newlines safely
                j += 1;
            }
            chunks.push(lit);
            i = j;
            continue;
        }

        // Not the pattern we handle; keep original text.
        out.push_str("loadstring");
        i += "loadstring".len();
    }

    Ok((chunks, out))
}

fn parse_lua_string_literal(s: &str, mut i: usize) -> Result<(String, usize), String> {
    let b = s.as_bytes();
    if i >= b.len() {
        return Err("unexpected EOF parsing literal".to_string());
    }

    // Quoted "..." or '...'
    if b[i] == b'"' || b[i] == b'\'' {
        let quote = b[i];
        i += 1;
        let mut out = String::new();
        while i < b.len() {
            let c = b[i];
            if c == quote {
                i += 1;
                return Ok((out, i));
            }
            if c == b'\\' {
                i += 1;
                if i >= b.len() {
                    return Err("unexpected EOF in escape".to_string());
                }
                let e = b[i];
                match e {
                    b'n' => out.push('\n'),
                    b'r' => out.push('\r'),
                    b't' => out.push('\t'),
                    b'\\' => out.push('\\'),
                    b'"' => out.push('"'),
                    b'\'' => out.push('\''),
                    _ => out.push(e as char),
                }
                i += 1;
                continue;
            }
            out.push(c as char);
            i += 1;
        }
        return Err("unterminated quoted string literal".to_string());
    }

    // Long bracket [=*[ ... ]=*]
    if b[i] == b'[' {
        let mut j = i + 1;
        while j < b.len() && b[j] == b'=' {
            j += 1;
        }
        if j >= b.len() || b[j] != b'[' {
            return Err("invalid long bracket literal".to_string());
        }
        let eq_count = j - (i + 1);
        j += 1; // content start
        let end_pat = {
            let mut p = String::new();
            p.push(']');
            for _ in 0..eq_count {
                p.push('=');
            }
            p.push(']');
            p
        };
        let content_start = j;
        let rest = &s[content_start..];
        let Some(end_pos) = rest.find(&end_pat) else {
            return Err("unterminated long bracket literal".to_string());
        };
        let content = &rest[..end_pos];
        let new_i = content_start + end_pos + end_pat.len();
        return Ok((content.to_string(), new_i));
    }

    Err("loadstring(...) only supported with string literals in this executor".to_string())
}

fn log_line(msg: &str) {
    println!("{}", msg);
    if let Ok(tmp) = std::env::temp_dir().into_os_string().into_string() {
        let path = format!("{}\\polytoria_interface.log", tmp.trim_end_matches(['\\', '/']));
        if let Ok(mut f) = OpenOptions::new().create(true).append(true).open(path) {
            let _ = writeln!(f, "{}", msg);
        }
    }
}
