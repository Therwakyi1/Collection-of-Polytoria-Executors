use std::ffi::{c_void, CStr, CString};
use windows::Win32::System::LibraryLoader::GetProcAddress;
use windows::Win32::Foundation::HMODULE;
use windows::core::PCSTR;

// Type Definitions
type FnIl2CppDomainGet = unsafe extern "C" fn() -> *mut c_void;
type FnIl2CppThreadAttach = unsafe extern "C" fn(domain: *mut c_void) -> *mut c_void;
type FnIl2CppStringNew = unsafe extern "C" fn(str: *const i8) -> *mut c_void;
type FnIl2CppDomainGetAssemblies = unsafe extern "C" fn(domain: *mut c_void, size: *mut usize) -> *mut *mut c_void;
type FnIl2CppAssemblyGetImage = unsafe extern "C" fn(assembly: *mut c_void) -> *mut c_void;
type FnIl2CppClassFromName = unsafe extern "C" fn(image: *mut c_void, namespace: *const i8, name: *const i8) -> *mut c_void;
type FnIl2CppObjectNew = unsafe extern "C" fn(params: *mut c_void) -> *mut c_void;
type FnIl2CppImageGetName = unsafe extern "C" fn(image: *mut c_void) -> *const i8;
type FnIl2CppClassGetFieldFromName = unsafe extern "C" fn(klass: *mut c_void, name: *const i8) -> *mut c_void;
type FnIl2CppClassGetMethodFromName = unsafe extern "C" fn(klass: *mut c_void, name: *const i8, args_count: i32) -> *mut c_void;
type FnIl2CppFieldGetOffset = unsafe extern "C" fn(field: *mut c_void) -> usize;
type FnIl2CppFieldStaticGetValue = unsafe extern "C" fn(field: *mut c_void, value: *mut c_void);
type FnIl2CppFieldStaticSetValue = unsafe extern "C" fn(field: *mut c_void, value: *mut c_void);
type FnIl2CppRuntimeInvoke = unsafe extern "C" fn(method: *mut c_void, obj: *mut c_void, params: *mut *mut c_void, exc: *mut *mut c_void) -> *mut c_void;
type FnIl2CppClassGetType = unsafe extern "C" fn(klass: *mut c_void) -> *mut c_void;
type FnIl2CppTypeGetObject = unsafe extern "C" fn(type_: *mut c_void) -> *mut c_void;
type FnIl2CppClassGetParent = unsafe extern "C" fn(klass: *mut c_void) -> *mut c_void;
type FnIl2CppObjectGetClass = unsafe extern "C" fn(obj: *mut c_void) -> *mut c_void;
type FnIl2CppStringLength = unsafe extern "C" fn(str: *mut c_void) -> i32;
type FnIl2CppStringChars = unsafe extern "C" fn(str: *mut c_void) -> *const u16;
type FnIl2CppMethodGetPointer = unsafe extern "C" fn(method: *mut c_void) -> *mut c_void;

#[derive(Clone)]
pub struct Il2Cpp {
    domain_get: FnIl2CppDomainGet,
    thread_attach: FnIl2CppThreadAttach,
    string_new: FnIl2CppStringNew,
    domain_get_assemblies: FnIl2CppDomainGetAssemblies,
    assembly_get_image: FnIl2CppAssemblyGetImage,
    class_from_name: FnIl2CppClassFromName,
    object_new: FnIl2CppObjectNew,
    image_get_name: FnIl2CppImageGetName,
    class_get_field_from_name: FnIl2CppClassGetFieldFromName,
    class_get_method_from_name: FnIl2CppClassGetMethodFromName,
    field_get_offset: FnIl2CppFieldGetOffset,
    field_static_get_value: FnIl2CppFieldStaticGetValue,
    field_static_set_value: FnIl2CppFieldStaticSetValue,
    runtime_invoke: FnIl2CppRuntimeInvoke,
    class_get_type: FnIl2CppClassGetType,
    type_get_object: FnIl2CppTypeGetObject,
    class_get_parent: FnIl2CppClassGetParent,
    object_get_class: FnIl2CppObjectGetClass,
    string_length: FnIl2CppStringLength,
    string_chars: FnIl2CppStringChars,
    method_get_pointer: Option<FnIl2CppMethodGetPointer>,
}

impl Il2Cpp {
    pub unsafe fn new(game_assembly: HMODULE) -> Option<Self> {
        let get_proc = |name: &str| {
            let name_c = CString::new(name).unwrap();
            GetProcAddress(game_assembly, PCSTR(name_c.as_ptr() as *const u8))
        };

        Some(Self {
            domain_get: std::mem::transmute(get_proc("il2cpp_domain_get")?),
            thread_attach: std::mem::transmute(get_proc("il2cpp_thread_attach")?),
            string_new: std::mem::transmute(get_proc("il2cpp_string_new")?),
            domain_get_assemblies: std::mem::transmute(get_proc("il2cpp_domain_get_assemblies")?),
            assembly_get_image: std::mem::transmute(get_proc("il2cpp_assembly_get_image")?),
            class_from_name: std::mem::transmute(get_proc("il2cpp_class_from_name")?),
            object_new: std::mem::transmute(get_proc("il2cpp_object_new")?),
            image_get_name: std::mem::transmute(get_proc("il2cpp_image_get_name")?),
            class_get_field_from_name: std::mem::transmute(get_proc("il2cpp_class_get_field_from_name")?),
            class_get_method_from_name: std::mem::transmute(get_proc("il2cpp_class_get_method_from_name")?),
            field_get_offset: std::mem::transmute(get_proc("il2cpp_field_get_offset")?),
            field_static_get_value: std::mem::transmute(get_proc("il2cpp_field_static_get_value")?),
            field_static_set_value: std::mem::transmute(get_proc("il2cpp_field_static_set_value")?),
            runtime_invoke: std::mem::transmute(get_proc("il2cpp_runtime_invoke")?),
            class_get_type: std::mem::transmute(get_proc("il2cpp_class_get_type")?),
            type_get_object: std::mem::transmute(get_proc("il2cpp_type_get_object")?),
            class_get_parent: std::mem::transmute(get_proc("il2cpp_class_get_parent")?),
            object_get_class: std::mem::transmute(get_proc("il2cpp_object_get_class")?),
            string_length: std::mem::transmute(get_proc("il2cpp_string_length")?),
            string_chars: std::mem::transmute(get_proc("il2cpp_string_chars")?),
            method_get_pointer: get_proc("il2cpp_method_get_pointer").map(|p| std::mem::transmute(p)),
        })
    }

    pub unsafe fn attach(&self) {
        let domain = (self.domain_get)();
        (self.thread_attach)(domain);
    }

    pub unsafe fn string_new(&self, s: &str) -> *mut c_void {
        let c_str = CString::new(s).unwrap();
        (self.string_new)(c_str.as_ptr())
    }

    pub unsafe fn get_image(&self, assembly_name: &str) -> Option<*mut c_void> {
        let domain = (self.domain_get)();
        let mut size = 0;
        let assemblies = (self.domain_get_assemblies)(domain, &mut size);
        
        for i in 0..size {
            let assembly = *assemblies.add(i);
            let image = (self.assembly_get_image)(assembly);
            let name_ptr = (self.image_get_name)(image);
            let name = CStr::from_ptr(name_ptr).to_string_lossy();
            
            // Usually assembly name matches image name but without extension sometimes
            // Logic: check valid name
            if name.contains(assembly_name) {
                return Some(image);
            }
        }
        None
    }

    pub unsafe fn get_class(&self, image: *mut c_void, namespace: &str, name: &str) -> Option<*mut c_void> {
        let ns = CString::new(namespace).unwrap();
        let n = CString::new(name).unwrap();
        let klass = (self.class_from_name)(image, ns.as_ptr(), n.as_ptr());
        if klass.is_null() { None } else { Some(klass) }
    }

    pub unsafe fn object_new(&self, klass: *mut c_void) -> *mut c_void {
        (self.object_new)(klass)
    }

    pub unsafe fn class_get_field_from_name(&self, klass: *mut c_void, name: &str) -> Option<*mut c_void> {
        let n = CString::new(name).unwrap();
        let field = (self.class_get_field_from_name)(klass, n.as_ptr());
        if field.is_null() { None } else { Some(field) }
    }

    pub unsafe fn field_get_offset(&self, field: *mut c_void) -> usize {
        (self.field_get_offset)(field)
    }

    pub unsafe fn field_static_get_value(&self, field: *mut c_void, value: *mut c_void) {
        (self.field_static_get_value)(field, value);
    }

    pub unsafe fn field_static_set_value(&self, field: *mut c_void, value: *mut c_void) {
        (self.field_static_set_value)(field, value);
    }

    pub unsafe fn class_get_method_from_name(&self, klass: *mut c_void, name: &str, args_count: i32) -> Option<*mut c_void> {
        let n = CString::new(name).unwrap();
        let method = (self.class_get_method_from_name)(klass, n.as_ptr(), args_count);
        if method.is_null() { None } else { Some(method) }
    }

    pub unsafe fn runtime_invoke(&self, method: *mut c_void, obj: *mut c_void, params: *mut *mut c_void) -> *mut c_void {
        let mut exc = std::ptr::null_mut();
        (self.runtime_invoke)(method, obj, params, &mut exc)
    }

    pub unsafe fn runtime_invoke_with_exc(
        &self,
        method: *mut c_void,
        obj: *mut c_void,
        params: *mut *mut c_void,
    ) -> (*mut c_void, *mut c_void) {
        let mut exc = std::ptr::null_mut();
        let ret = (self.runtime_invoke)(method, obj, params, &mut exc);
        (ret, exc)
    }

    pub unsafe fn class_get_type(&self, klass: *mut c_void) -> *mut c_void {
        (self.class_get_type)(klass)
    }

    pub unsafe fn type_get_object(&self, type_: *mut c_void) -> *mut c_void {
        (self.type_get_object)(type_)
    }

    pub unsafe fn class_get_parent(&self, klass: *mut c_void) -> Option<*mut c_void> {
        let parent = (self.class_get_parent)(klass);
        if parent.is_null() { None } else { Some(parent) }
    }

    pub unsafe fn object_get_class(&self, obj: *mut c_void) -> *mut c_void {
        (self.object_get_class)(obj)
    }

    pub unsafe fn string_to_rust(&self, s: *mut c_void) -> String {
        if s.is_null() {
            return "<null>".to_string();
        }
        let len = (self.string_length)(s);
        if len <= 0 {
            return String::new();
        }
        let ptr = (self.string_chars)(s);
        if ptr.is_null() {
            return "<bad_string>".to_string();
        }
        let slice = std::slice::from_raw_parts(ptr, len as usize);
        String::from_utf16_lossy(slice)
    }

    pub unsafe fn method_get_pointer(&self, method: *mut c_void) -> Option<*mut c_void> {
        self.method_get_pointer.map(|f| f(method))
    }
}
